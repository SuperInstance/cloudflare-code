# 🔮 Cloudflare Multi-Tenant Architecture

## 🎯 Architecture Overview

STEM Builder is designed as a **multi-tenant portal** where each user connects their own Cloudflare account. The application itself is stateless and scalable, with all heavy lifting distributed across users' Cloudflare resources.

## 🏗️ Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    Cloudflare Pages (Frontend)                │
│              STEM Builder - Next.js Application                │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ├─────────┬─────────┬─────────┐
                       │         │         │         │
                User A   User B   User C   User D
                   │         │         │         │
                   │         │         │         │
            ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
            │ OAuth  │ │ OAuth  │ │ OAuth  │ │ OAuth  │
            │ Token  │ │ Token  │ │ Token  │ │ Token  │
            └───┬────┘ └───┬────┘ └───┬────┘ └───┬────┘
                │           │           │           │
                ▼           ▼           ▼           ▼
         ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
         │User's CF │ │User's CF │ │User's CF │ │User's CF │
         │ Account  │ │ Account  │ │ Account  │ │ Account  │
         └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘
              │            │            │            │
    ┌─────────┴─────────┴────────────┴────────────┴───────┐
    │              Per-User Cloudflare Services              │
    │                                                      │
    │  • Workers AI (Chatbot & Image Generation)             │
    │  • Vector DB (User learning & context)                │
    │  • R2 Storage (Projects & components)                  │
    │  • KV Store (Session & cache)                         │
    │  • D1 Database (User metadata & configs)               │
    └──────────────────────────────────────────────────────────────┘
```

## 🔄 User Flow

### 1. Initial Access
```
1. User visits app.domain.com
2. Presented with "Connect Cloudflare Account" button
3. Clicks OAuth button → Redirected to Cloudflare
4. User authorizes app → OAuth tokens returned
5. Tokens stored in secure session (browser + CF KV)
```

### 2. Using the App
```
1. User chats with AI
2. Frontend sends request to user's Cloudflare Worker
3. Worker:
   - Uses user's Workers AI for chat
   - Stores context in user's Vector DB
   - Tracks usage in user's D1
4. Response returned to frontend
```

### 3. Creating Components
```
1. User creates custom component
2. Frontend sends to user's Cloudflare Worker
3. Worker:
   - Generates image using user's Workers AI
   - Stores image in user's R2 bucket
   - Saves metadata in user's D1
4. URL returned to frontend
```

### 4. Saving Projects
```
1. User saves project
2. Frontend sends project data to user's Cloudflare Worker
3. Worker:
   - Stores JSON in user's R2
   - Indexes metadata in user's D1
4. Confirmation returned
```

## 💡 Key Benefits

### ✅ Infinite Scalability
- Each user uses their own Cloudflare limits
- No shared bottlenecks
- Auto-scales with Cloudflare's infrastructure

### ✅ Cost Efficiency
- App costs: ~$0 (just frontend hosting on Pages)
- User costs: Only their own usage (Free tier available)
- No shared resource contention

### ✅ Privacy & Security
- User data stays in their Cloudflare account
- OAuth tokens stored securely in user's session
- No shared user data or leakage

### ✅ Customization
- Each user can:
  - Choose their AI models
  - Configure their storage
  - Set up custom Workers
  - Use their own limits

### ✅ Reliability
- No single point of failure
- Each user isolated
- DDoS protection per user

## 🛠️ Cloudflare Services Used

### Frontend
- **Cloudflare Pages**: Deploy Next.js application
  - Global CDN
  - Automatic HTTPS
  - Preview deployments

### Authentication
- **Cloudflare OAuth**: Secure user authentication
  - Account linking
  - Token management
  - Session handling

### Backend (Per User)
- **Workers AI**: AI chatbot and image generation
  - Text generation (@cf/meta/llama-2-7b-chat-int8)
  - Image generation (@cf/stabilityai/stable-diffusion-xl-base-1.0)

- **Vector Database**: User learning and context
  - Store chat history as embeddings
  - Semantic search for context retrieval
  - Personalized AI responses

- **R2 Storage**: File storage
  - User projects
  - Generated images
  - Component assets

- **D1 Database**: Structured data
  - User configurations
  - Project metadata
  - Component library
  - Usage tracking

- **KV Store**: Fast lookups
  - Session data
  - Cache layer
  - OAuth tokens (encrypted)

- **Workers**: Custom backend logic
  - API routing
  - Data processing
  - AI orchestration

## 🚀 Deployment Architecture

### Cloudflare Pages (App Hosting)
```
stem-builder.your-domain.com
  └─ Next.js Application
      ├─ Static assets (CDN)
      ├─ API routes (Edge functions)
      └─ Client-side routing
```

### Per-User Cloudflare Account
```
User's Cloudflare Account
  ├─ Worker: stem-builder-api
  │   ├─ Routes: /api/chat
  │   ├─ Routes: /api/components
  │   └─ Routes: /api/projects
  ├─ R2 Bucket: stem-builder-storage
  ├─ D1 Database: stem-builder-db
  ├─ KV Namespace: stem-builder-cache
  └─ Vector Index: stem-builder-vectors
```

## 🔐 Security Model

### OAuth Flow
1. **Authorization Code Flow**
   - User redirected to Cloudflare
   - User approves app
   - Authorization code returned
   - Exchange for access token

2. **Token Storage**
   - Access token: Short-lived (1 hour)
   - Refresh token: Long-lived (30 days)
   - Stored in: Cloudflare KV (encrypted)

3. **Token Usage**
   - Each API call uses user's access token
   - Auto-refresh on expiration
   - Revoked on user logout

### API Security
- **CORS**: Restrict to app domain
- **Rate Limiting**: Per-user limits
- **Input Validation**: Sanitize all inputs
- **Encryption**: Encrypt sensitive data in KV

## 📊 Resource Limits

### App (Cloudflare Pages)
- **Requests**: Unlimited
- **Bandwidth**: Unlimited
- **Builds**: 500/month (Free tier)
- **Cost**: $0 (Free tier)

### Per User (Cloudflare Free Tier)
- **Workers**: 100,000 requests/day
- **Workers AI**: 10,000 neurons/day
- **R2 Storage**: 10GB
- **D1**: 5GB storage, 5M rows/day
- **KV**: 100k reads/day, 1k writes/day
- **Vector DB**: 1M vectors, 20k index operations/day

### Per User (Paid Tier - if needed)
- **Workers**: $0.50/Million requests
- **Workers AI**: $0.0001/1k neurons
- **R2**: $0.015/GB-month
- **D1**: $0.50/GB-month + $0.01/M rows

## 🔄 Data Flow Example

### Chat Request
```
Frontend
  ↓ (HTTP POST with OAuth token)
User's Worker (CF Worker)
  ↓ (Workers AI API)
Cloudflare AI (@cf/meta/llama-2-7b-chat-int8)
  ↓ (AI response)
User's Worker
  ↓ (Vector DB API)
Cloudflare Vector DB (Store embedding)
  ↓ (D1 API)
Cloudflare D1 (Log usage)
  ↓ (HTTP Response)
Frontend
```

## 🎯 Implementation Phases

### Phase 1: Authentication ✅
- Implement Cloudflare OAuth
- Session management
- Token handling

### Phase 2: Basic API ✅
- Create Cloudflare Worker
- Basic chat endpoint
- Basic component storage

### Phase 3: AI Integration ✅
- Workers AI chatbot
- Workers AI image generation
- Vector DB for context

### Phase 4: Full Features ✅
- Project save/load
- Component library
- User dashboard
- Usage tracking

### Phase 5: Advanced ✅
- Custom Workers
- Multi-account support
- Advanced AI features
- Collaborative features

## 📝 Migration Path

### From Local SQLite to Cloudflare D1
1. Export SQLite schema
2. Create D1 database
3. Migrate schema to D1 SQL
4. Update APIs to use D1
5. Remove Prisma dependency

### From z-ai-web-dev-sdk to Workers AI
1. Replace LLM calls with Workers AI
2. Replace image generation with Workers AI
3. Update prompts for available models
4. Test and validate

## 🌟 Unique Advantages

1. **Truly Multi-Tenant**: Each user isolated, no shared resources
2. **Zero Infrastructure Cost**: App hosting is free on Pages
3. **User Pays for Usage**: Users control their own costs
4. **Global Edge**: Everything runs at the edge
5. **Instant Scale**: Cloudflare auto-scales
6. **Privacy First**: User data never leaves their account
7. **Custom Workers**: Users can extend with their own code
8. **No Vendor Lock-in**: Users own everything

---

This architecture transforms STEM Builder from a traditional SaaS into a distributed, user-controlled, infinitely scalable platform.
