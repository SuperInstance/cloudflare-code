/**
 * STEM Builder Cloudflare Worker Template
 *
 * Deploy this to your Cloudflare account to enable:
 * - AI Chatbot (Workers AI)
 * - Image Generation (Workers AI)
 * - Vector Database (for user learning)
 * - R2 Storage (for projects and components)
 * - D1 Database (for metadata)
 *
 * Deployment Instructions:
 * 1. Create a Cloudflare Worker named "stem-builder-api"
 * 2. Copy this code to the Worker
 * 3. Bind services:
 *    - D1: DB (stem-builder-db)
 *    - R2: STORAGE (stem-builder-storage)
 *    - KV: CACHE (stem-builder-cache)
 *    - Vectorize: VECTORS (stem-builder-vectors)
 * 4. Deploy the Worker
 * 5. Use the Worker URL in STEM Builder settings
 */

export interface Env {
  // D1 Database
  DB: D1Database;

  // R2 Storage
  STORAGE: R2Bucket;

  // KV Store
  CACHE: KVNamespace;

  // Vectorize Index
  VECTORS: VectorizeIndex;

  // Environment variables
  AI_MODEL?: string;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp?: number;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  thumbnail?: string;
  components: ProjectComponent[];
  createdAt: number;
  updatedAt: number;
}

export interface ProjectComponent {
  id: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  properties: Record<string, any>;
  wiringData?: Record<string, any>;
  codeSnippet?: string;
  detailLevel: number;
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // API Routes
    try {
      if (path === '/api/health') {
        return handleHealth(env);
      }

      if (path === '/api/chat' && request.method === 'POST') {
        return handleChat(request, env, ctx);
      }

      if (path === '/api/generate-image' && request.method === 'POST') {
        return handleGenerateImage(request, env);
      }

      if (path === '/api/projects' && request.method === 'GET') {
        return handleGetProjects(request, env);
      }

      if (path === '/api/projects' && request.method === 'POST') {
        return handleCreateProject(request, env);
      }

      if (path.startsWith('/api/projects/') && request.method === 'GET') {
        const projectId = path.split('/')[3];
        return handleGetProject(projectId, env);
      }

      if (path.startsWith('/api/projects/') && request.method === 'PUT') {
        const projectId = path.split('/')[3];
        return handleUpdateProject(projectId, request, env);
      }

      if (path.startsWith('/api/projects/') && request.method === 'DELETE') {
        const projectId = path.split('/')[3];
        return handleDeleteProject(projectId, env);
      }

      if (path === '/api/components' && request.method === 'GET') {
        return handleGetComponents(request, env);
      }

      if (path === '/api/components' && request.method === 'POST') {
        return handleCreateComponent(request, env);
      }

      return new Response(
        JSON.stringify({ error: 'Not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } catch (error) {
      console.error('Worker error:', error);
      return new Response(
        JSON.stringify({ error: 'Internal server error', details: String(error) }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  },
};

// Health check
async function handleHealth(env: Env): Promise<Response> {
  return new Response(
    JSON.stringify({
      status: 'healthy',
      services: {
        db: !!env.DB,
        storage: !!env.STORAGE,
        cache: !!env.CACHE,
        vectors: !!env.VECTORS,
        ai: true
      }
    }),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Chat endpoint using Workers AI
async function handleChat(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
  try {
    const { messages, userId } = await request.json();

    // Get chat history from Vector DB for context
    const context = await getChatContext(userId, messages, env);

    // Prepare messages with system prompt
    const systemPrompt = {
      role: 'system' as const,
      content: `You are an expert STEM educator and electrical engineering assistant for a gamified construction game called "STEM Builder".

Your role is to help players:
1. Create and design custom components for their projects
2. Understand how components work together
3. Suggest project ideas and challenges
4. Explain electrical and mechanical concepts in simple terms
5. Provide guidance on wiring and code generation

When a user asks for custom components:
- Suggest realistic components that would work in real STEM projects
- Describe their appearance, function, and typical uses
- Mention how they might connect to other components
- Keep descriptions imaginative but grounded in real physics/engineering

When explaining concepts:
- Use simple language appropriate for the player's apparent level
- Provide practical examples
- Encourage experimentation and learning

${context ? `Previous conversation context: ${context}` : ''}`
    };

    const allMessages = [systemPrompt, ...messages];

    // Use Workers AI for chat completion
    const aiResponse = await env.AI.run(
      '@cf/meta/llama-2-7b-chat-int8' as any,
      {
        messages: allMessages,
        stream: false
      }
    );

    const assistantMessage = aiResponse.response || aiResponse.generated_text;

    // Store conversation in Vector DB for future context
    if (userId && messages[messages.length - 1]?.role === 'user') {
      await storeInVectorDB(
        userId,
        messages[messages.length - 1].content,
        assistantMessage,
        env
      );
    }

    // Log usage to D1
    await env.DB.prepare(
      'INSERT INTO usage_logs (user_id, action, tokens, timestamp) VALUES (?, ?, ?, ?)'
    ).bind(userId, 'chat', 100, Date.now()).run();

    return new Response(
      JSON.stringify({
        message: {
          role: 'assistant',
          content: assistantMessage
        }
      }),
      { headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Chat error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to process chat', details: String(error) }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

// Image generation using Workers AI
async function handleGenerateImage(request: Request, env: Env): Promise<Response> {
  try {
    const { prompt, componentType, category } = await request.json();

    // Enhance prompt for technical illustrations
    const enhancedPrompt = `Professional technical illustration of a ${componentType || 'electronic component'} for STEM education. ${prompt}. Clean white background, isometric view, educational diagram style, high detail, labeled pins clearly visible.`;

    // Use Workers AI for image generation
    const aiResponse = await env.AI.run(
      '@cf/stabilityai/stable-diffusion-xl-base-1.0' as any,
      {
        prompt: enhancedPrompt,
        image_size: '1024x1024'
      }
    );

    // The response is base64 encoded
    const imageBase64 = aiResponse.image || aiResponse.data?.[0]?.base64;

    if (!imageBase64) {
      throw new Error('No image data in response');
    }

    // Convert base64 to buffer
    const imageBuffer = Uint8Array.from(atob(imageBase64), c => c.charCodeAt(0));

    // Generate filename
    const filename = `${componentType || 'component'}-${Date.now()}.png`;
    const key = `generated-components/${filename}`;

    // Store in R2
    await env.STORAGE.put(key, imageBuffer, {
      httpMetadata: {
        contentType: 'image/png'
      }
    });

    // Return URL (Worker URL + key)
    const workerUrl = new URL(request.url);
    const imageUrl = `${workerUrl.origin}/storage/${key}`;

    return new Response(
      JSON.stringify({
        success: true,
        imageUrl,
        filename,
        prompt: enhancedPrompt
      }),
      { headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Image generation error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to generate image', details: String(error) }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

// Get all projects
async function handleGetProjects(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const userId = url.searchParams.get('userId');

  if (!userId) {
    return new Response(
      JSON.stringify({ error: 'userId required' }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }

  const projects = await env.DB.prepare(
    'SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC'
  ).bind(userId).all();

  return new Response(
    JSON.stringify(projects.results || []),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Create project
async function handleCreateProject(request: Request, env: Env): Promise<Response> {
  const { name, description, userId, components } = await request.json();

  const projectId = crypto.randomUUID();
  const now = Date.now();

  // Save to D1
  await env.DB.prepare(
    'INSERT INTO projects (id, name, description, user_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).bind(projectId, name, description, userId, now, now).run();

  // Save components JSON to R2
  if (components) {
    await env.STORAGE.put(
      `projects/${projectId}/components.json`,
      JSON.stringify(components),
      {
        httpMetadata: { contentType: 'application/json' }
      }
    );
  }

  return new Response(
    JSON.stringify({ id: projectId, name, description, createdAt: now }),
    { status: 201, headers: { 'Content-Type': 'application/json' } }
  );
}

// Get single project
async function handleGetProject(projectId: string, env: Env): Promise<Response> {
  const project = await env.DB.prepare(
    'SELECT * FROM projects WHERE id = ?'
  ).bind(projectId).first();

  if (!project) {
    return new Response(
      JSON.stringify({ error: 'Project not found' }),
      { status: 404, headers: { 'Content-Type': 'application/json' } }
    );
  }

  // Get components from R2
  const componentsObject = await env.STORAGE.get(`projects/${projectId}/components.json`);
  const components = componentsObject
    ? await componentsObject.json()
    : [];

  return new Response(
    JSON.stringify({ ...project, components }),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Update project
async function handleUpdateProject(projectId: string, request: Request, env: Env): Promise<Response> {
  const { name, description, components } = await request.json();

  await env.DB.prepare(
    'UPDATE projects SET name = ?, description = ?, updated_at = ? WHERE id = ?'
  ).bind(name, description, Date.now(), projectId).run();

  if (components) {
    await env.STORAGE.put(
      `projects/${projectId}/components.json`,
      JSON.stringify(components),
      {
        httpMetadata: { contentType: 'application/json' }
      }
    );
  }

  return new Response(
    JSON.stringify({ success: true }),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Delete project
async function handleDeleteProject(projectId: string, env: Env): Promise<Response> {
  await env.DB.prepare('DELETE FROM projects WHERE id = ?').bind(projectId).run();

  // Delete components from R2
  await env.STORAGE.delete(`projects/${projectId}/components.json`);

  return new Response(
    JSON.stringify({ success: true }),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Get components
async function handleGetComponents(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const category = url.searchParams.get('category');
  const isCustom = url.searchParams.get('custom');

  let query = 'SELECT * FROM components';
  const conditions = [];
  const params: any[] = [];

  if (category) {
    conditions.push('category = ?');
    params.push(category);
  }

  if (isCustom !== null) {
    conditions.push('is_custom = ?');
    params.push(isCustom === 'true');
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  const components = await env.DB.prepare(query).bind(...params).all();

  return new Response(
    JSON.stringify(components.results || []),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Create component
async function handleCreateComponent(request: Request, env: Env): Promise<Response> {
  const { name, category, description, type, imageUrl, isCustom } = await request.json();

  const componentId = crypto.randomUUID();

  await env.DB.prepare(
    'INSERT INTO components (id, name, category, description, type, image_url, is_custom, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(componentId, name, category, description, type, imageUrl, isCustom || false, Date.now()).run();

  return new Response(
    JSON.stringify({ id: componentId, name, category, description, type, imageUrl, isCustom }),
    { status: 201, headers: { 'Content-Type': 'application/json' } }
  );
}

// Vector DB helpers
async function getChatContext(userId: string, currentMessages: ChatMessage[], env: Env): Promise<string> {
  if (!env.VECTORS) {
    return '';
  }

  try {
    // Get the last user message for embedding
    const lastUserMessage = currentMessages.filter(m => m.role === 'user').pop();
    if (!lastUserMessage) {
      return '';
    }

    // Generate embedding
    const embedding = await env.AI.run('@cf/baai/bge-base-en-v1.5' as any, {
      text: lastUserMessage.content
    });

    // Search vector DB for similar conversations
    const results = await env.VECTORS.query(embedding.data, {
      topK: 3,
      namespace: `user-${userId}`,
      returnMetadata: true
    });

    // Extract context from results
    const contexts = results.matches?.map(m => m.metadata?.context) || [];
    return contexts.filter(Boolean).join('\n\n');
  } catch (error) {
    console.error('Vector DB error:', error);
    return '';
  }
}

async function storeInVectorDB(userId: string, userMessage: string, assistantMessage: string, env: Env): Promise<void> {
  if (!env.VECTORS) {
    return;
  }

  try {
    // Generate embedding for user message
    const embedding = await env.AI.run('@cf/baai/bge-base-en-v1.5' as any, {
      text: userMessage
    });

    // Store in vector DB
    await env.VECTORS.insert({
      id: crypto.randomUUID(),
      values: embedding.data,
      namespace: `user-${userId}`,
      metadata: {
        userMessage,
        assistantMessage,
        context: `${userMessage}\n${assistantMessage}`,
        timestamp: Date.now()
      }
    });
  } catch (error) {
    console.error('Vector DB insert error:', error);
  }
}
