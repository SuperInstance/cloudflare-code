# 🚀 Cloudflare Worker Deployment Guide

Follow these steps to deploy your personal STEM Builder Worker to your Cloudflare account.

## Prerequisites

1. **Cloudflare Account** - Create a free account at https://dash.cloudflare.com
2. **Node.js** - Install Node.js (https://nodejs.org)
3. **Wrangler CLI** - Install Cloudflare's CLI:
   ```bash
   npm install -g wrangler
   ```

## Step 1: Login to Cloudflare

```bash
wrangler login
```

This will open your browser to authenticate with Cloudflare.

## Step 2: Create D1 Database

```bash
wrangler d1 create stem-builder-db
```

Copy the `database_id` from the output - you'll need it for `wrangler.toml`.

## Step 3: Create R2 Bucket

```bash
wrangler r2 bucket create stem-builder-storage
```

## Step 4: Create KV Namespace

```bash
wrangler kv:namespace create "STEM_BUILDER_CACHE"
```

Copy the `id` from the output - you'll need it for `wrangler.toml`.

## Step 5: Create Vectorize Index

```bash
wrangler vectorize create stem-builder-vectors \
  --dimensions=768 \
  --metric=cosine
```

Copy the `index_name` from the output.

## Step 6: Initialize Database Schema

```bash
wrangler d1 execute stem-builder-db --file=./cloudflare-workers/d1-schema.sql
```

## Step 7: Configure Worker

1. Copy `cloudflare-workers/worker-template.ts` to a new directory
2. Rename it to `worker.ts`
3. Copy `cloudflare-workers/wrangler.toml` to the same directory
4. Edit `wrangler.toml` and replace the placeholders:
   - `<YOUR_D1_DATABASE_ID>` - From Step 2
   - `<YOUR_KV_NAMESPACE_ID>` - From Step 4

Your `wrangler.toml` should look like:

```toml
name = "stem-builder-api"
main = "worker.ts"
compatibility_date = "2024-01-01"

[[d1_databases]]
binding = "DB"
database_name = "stem-builder-db"
database_id = "a1b2c3d4-1234-5678-90ab-cdef12345678"

[[r2_buckets]]
binding = "STORAGE"
bucket_name = "stem-builder-storage"

[[kv_namespaces]]
binding = "CACHE"
id = "e5f6g7h8-9012-3456-78cd-efab12345678"

[[vectorize]]
binding = "VECTORS"
index_name = "stem-builder-vectors"

[vars]
ENVIRONMENT = "production"
```

## Step 8: Deploy Worker

```bash
cd /path/to/your/worker/directory
wrangler deploy
```

After successful deployment, Wrangler will show your Worker URL:
```
Published stem-builder-api
  https://stem-builder-api.your-subdomain.workers.dev
```

## Step 9: Test Your Worker

Test that your Worker is running correctly:

```bash
curl https://stem-builder-api.your-subdomain.workers.dev/api/health
```

Expected response:
```json
{
  "status": "healthy",
  "services": {
    "db": true,
    "storage": true,
    "cache": true,
    "vectors": true,
    "ai": true
  }
}
```

## Step 10: Connect to STEM Builder

1. Open STEM Builder web app
2. Click "Settings" (⚙️)
3. In "Cloudflare Worker URL" field, enter your Worker URL:
   ```
   https://stem-builder-api.your-subdomain.workers.dev
   ```
4. Click "Save Configuration"

## Optional: Custom Domain

To use your own domain for the Worker:

1. Add a CNAME record to your domain's DNS:
   ```
   api.your-domain.com → stem-builder-api.your-subdomain.workers.dev
   ```

2. Add the route to `wrangler.toml`:
   ```toml
   [[routes]]
   pattern = "api.your-domain.com/*"
   zone_name = "your-domain.com"
   ```

3. Redeploy:
   ```bash
   wrangler deploy
   ```

## Optional: Add Default Components

Populate your component library with default components using the API:

```bash
# Upload default components
curl -X POST https://your-worker-url/api/components \
  -H "Content-Type: application/json" \
  -d '{
    "name": "ESP32 Microcontroller",
    "category": "controller",
    "description": "A powerful microcontroller with WiFi and Bluetooth capabilities",
    "type": "esp32",
    "imageUrl": null,
    "isCustom": false
  }'
```

Repeat for all default components or use the initialization script.

## Monitoring Your Worker

### View Logs
```bash
wrangler tail
```

### View Statistics
Visit Cloudflare Dashboard → Workers & Pages → stem-builder-api

## Troubleshooting

### Database Not Found
Error: `D1_ERROR: Database not found`
- Ensure you created the database in Step 2
- Verify the database_id in wrangler.toml matches

### Workers AI Not Available
Error: `Model not found` or `Workers AI not enabled`
- Ensure Workers AI is enabled in your Cloudflare account
- Verify the model names are correct

### Vector Index Not Ready
Error: `Vectorize index not ready`
- Wait a few minutes after creating the index
- Check the Vectorize status in Cloudflare Dashboard

### CORS Errors
Error: `Access blocked by CORS policy`
- Ensure your Worker includes CORS headers
- Check that the STEM Builder app domain is allowed

## Security Best Practices

1. **Never commit secrets** - Keep your wrangler.toml with real IDs private
2. **Use environment variables** - For sensitive configuration
3. **Enable rate limiting** - In your Worker code
4. **Monitor usage** - Check Cloudflare Dashboard regularly
5. **Rotate tokens** - Regularly update OAuth tokens

## Costs

### Free Tier (Per User)
- Workers: 100,000 requests/day
- Workers AI: 10,000 neurons/day
- R2: 10GB storage
- D1: 5GB storage, 5M rows/day
- KV: 100k reads/day, 1k writes/day
- Vectorize: 1M vectors, 20k operations/day

### Paid Tier (If Needed)
- Workers: $0.50/Million requests
- Workers AI: $0.0001/1k neurons
- R2: $0.015/GB-month
- D1: $0.50/GB-month + $0.01/M rows

## Next Steps

After deploying your Worker:

1. ✅ Test all API endpoints
2. ✅ Verify AI chat works
3. ✅ Test image generation
4. ✅ Create a test project
5. ✅ Save and load projects
6. ✅ Monitor your usage

Your Worker is now ready to power your STEM Builder experience!

## Support

- Cloudflare Docs: https://developers.cloudflare.com
- Workers AI: https://developers.cloudflare.com/workers-ai
- Vectorize: https://developers.cloudflare.com/vectorize
- R2 Storage: https://developers.cloudflare.com/r2
- D1 Database: https://developers.cloudflare.com/d1
