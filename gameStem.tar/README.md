# 🔧 STEM Builder - AI-Powered Construction Game (Cloudflare Multi-Tenant)

A revolutionary gamified STEM construction platform that uses generative AI to help players build, simulate, and learn about real electronic components. Inspired by The Incredible Machine and Minecraft, but with real-world components.

**🌟 Unique Multi-Tenant Architecture** - Each user connects their own Cloudflare account for AI, storage, and database. Zero infrastructure cost for the app. Infinite scalability.

## 🎮 Game Concept

STEM Builder provides a progressive learning experience where complexity grows with player curiosity:

1. **Visual Level** - Components appear and work visually. Perfect for beginners and creative experimentation.
2. **Wiring Level** - Real wiring connections are revealed. Players learn electrical engineering principles.
3. **Code Level** - Actual code snippets are generated. Advanced users dive into programming.

### Key Features

- **🤖 AI-Powered Components** - Ask chatbot to create custom components with unique properties
- **🔌 Progressive Detail System** - Game complexity matches player exploration level
- **🎨 Visual Simulation** - Components work mechanically without perfect code implementation
- **📝 Real Wiring & Code** - Deep examination reveals actual connections and code
- **🎓 Educational** - Learn STEM concepts through hands-on building
- **🌐 Multi-Tenant** - Each user uses their own Cloudflare resources
- **🛡️ Privacy-First** - Your data stays in your Cloudflare account
- **💰 Zero Cost** - App is free, you only pay for your own usage

## 🏗️ Architecture

### Multi-Tenant Design

```
                    ┌──────────────────────┐
                    │  Cloudflare Pages    │
                    │  stem-builder.app    │
                    └──────────┬───────────┘
                               │
                ┌────────────┴────────────┐
                │                         │
         User A                     User B
           │                           │
      ┌────┴────┐              ┌────┴────┐
      │   CF     │              │   CF     │
      │ Account  │              │ Account  │
      │          │              │          │
      ├─ Workers AI             ├─ Workers AI
      ├─ R2 Storage            ├─ R2 Storage
      ├─ D1 Database           ├─ D1 Database
      ├─ Vector DB             ├─ Vector DB
      └─ KV Store              └─ KV Store
```

**Why This Architecture?**
- ✅ Infinite scalability (each user has own limits)
- ✅ Zero infrastructure cost for the app
- ✅ User data stays in their account (privacy-first)
- ✅ No shared bottlenecks
- ✅ Users control their costs
- ✅ No vendor lock-in

**Learn More:**
- [CLOUDFLARE_ARCHITECTURE.md](./CLOUDFLARE_ARCHITECTURE.md) - Technical architecture
- [MULTI_TENANT_GUIDE.md](./MULTI_TENANT_GUIDE.md) - User guide
- [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) - Deployment guide

## 🚀 Quick Start

### Option 1: Use Demo Mode (No Worker Required)

```bash
# Install dependencies
bun install

# Start development server
bun run dev
```

Open [http://localhost:3000](http://localhost:3000)

### Option 2: Deploy to Cloudflare Pages (Full Multi-Tenant)

See [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) for complete deployment instructions.

### Option 3: Deploy Your Personal Worker

Each user deploys their own Worker for AI, storage, and database. See [cloudflare-workers/DEPLOYMENT.md](./cloudflare-workers/DEPLOYMENT.md).

```bash
npm install -g wrangler
wrangler login
wrangler d1 create stem-builder-db
wrangler r2 bucket create stem-builder-storage
wrangler kv:namespace create STEM_BUILDER_CACHE
wrangler vectorize create stem-builder-vectors --dimensions=768 --metric=cosine
wrangler d1 execute stem-builder-db --file=./cloudflare-workers/d1-schema.sql
wrangler deploy
```

## ✨ Technology Stack

### Frontend
- **Next.js 15** - React framework with App Router
- **TypeScript 5** - Type-safe development
- **Tailwind CSS 4** - Modern styling
- **shadcn/ui** - Beautiful UI components

### Deployment (Cloudflare)
- **Cloudflare Pages** - Frontend hosting (free)
- **Cloudflare Workers** - Serverless compute
- **OAuth** - Secure authentication

### Per User (Their Cloudflare)
- **Workers AI** - LLM & image generation
- **Vectorize** - Vector database for learning
- **R2 Storage** - Object storage for projects
- **D1 Database** - SQL database for metadata
- **KV Store** - Fast cache layer

## 🎮 How to Play

### For Beginners
1. Drag components from library to canvas
2. Ask AI chatbot to create imaginary parts
3. Experiment freely - parts work visually!
4. Learn by doing without worrying about wiring or code

### For Intermediate Players
1. Build projects with real components (ESP32, motors, sensors)
2. Switch to "Wiring" detail level to see connections
3. Learn electrical principles
4. Complete challenges and puzzles

### For Advanced Users
1. Switch to "Code" detail level
2. See actual code snippets for components
3. Modify and understand code
4. Build complex systems with multiple components

## 🔧 Available Components

### Controllers
- ESP32 Microcontroller
- Jetson Nano

### Actuators
- DC Motor
- Servo Motor
- Wheel
- LED

### Sensors
- Temperature Sensor
- Motion Sensor (PIR)
- Ultrasonic Sensor

### Inputs
- Push Button
- Toggle Switch

### Power
- Battery Pack

### Communication
- WiFi Module
- Bluetooth Module

### Custom Components
- Ask AI to create any component you imagine!

## 🤖 AI Features

### Chatbot Capabilities
- Create custom components based on descriptions
- Explain how parts work together
- Suggest project ideas
- Provide technical guidance
- Generate code snippets

### Personalization (Your Vector DB)
- Learns from your conversations
- Remembers your preferences
- Provides context-aware responses
- Semantic search of your history

### Image Generation
- Generate visual representations of custom components
- Create technical illustrations
- Design unique part appearances

## 🌐 Cloudflare Integration

### Connect Your Cloudflare Account

1. Click "Connect with Cloudflare" in the app
2. Authorize STEM Builder
3. Enter your Worker URL in settings
4. Start using your own resources!

### What You Get

- **Personal AI** - Workers AI with your history
- **Unlimited Projects** - Your R2 bucket
- **Smart Learning** - Your Vector DB
- **Full Control** - Your data, your way

### Costs

**For the App**: $0/month (Cloudflare Pages free tier)

**Per User (Free Tier)**:
- 100,000 Worker requests/day
- 10,000 AI neurons/day
- 10GB R2 storage
- 5GB D1 database
- 100K KV reads/day, 1K writes/day
- 1M vectors in Vector DB

**Per User (Paid)**: Only if you exceed free tier
- Workers: $0.50/Million requests
- Workers AI: $0.0001/1k neurons
- R2: $0.015/GB-month
- D1: $0.50/GB-month + $0.01/M rows

## 📁 Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── cloudflare/      # OAuth and account APIs
│   │   ├── config/         # API configuration endpoints
│   │   ├── chat/           # LLM chatbot
│   │   ├── components/     # Component library
│   │   └── generate-image/ # Image generation
│   ├── page.tsx           # Main game interface
│   └── layout.tsx         # Root layout
├── components/
│   ├── cloudflare/         # Cloudflare integration components
│   └── ui/               # shadcn/ui components
└── lib/
    ├── db.ts              # Prisma client (legacy)
    └── utils.ts           # Utility functions

cloudflare-workers/
├── worker-template.ts    # Worker deployment template
├── d1-schema.sql       # Database schema
├── wrangler.toml       # Worker configuration
└── DEPLOYMENT.md       # User deployment guide
```

## 🎯 Development Roadmap

### Completed ✅
- [x] Multi-tenant Cloudflare architecture
- [x] Cloudflare OAuth authentication
- [x] Cloudflare Worker backend template
- [x] Workers AI integration
- [x] Vector DB for user learning
- [x] R2 storage integration
- [x] D1 database schema
- [x] Frontend UI components

### In Progress 🚧
- [ ] Component drag-and-drop
- [ ] Canvas construction workspace
- [ ] Visual simulation

### Planned 📋
- [ ] Wiring detail level implementation
- [ ] Code generation system
- [ ] Project save/load (to user's R2)
- [ ] Challenge and puzzle system
- [ ] Adventure mode
- [ ] Real-time collaboration

## 🎓 Educational Goals

STEM Builder aims to teach:

1. **Electronics** - Understanding circuits, components, and connections
2. **Programming** - Learning to control hardware with code
3. **Engineering** - Problem-solving and system design
4. **Creativity** - Building unique projects and solutions
5. **Independence** - Learning to manage your own infrastructure

## 🤝 Contributing

This is an educational project aimed at making STEM learning fun and accessible. Ideas, feedback, and contributions are welcome!

## 📝 License

MIT License - Feel free to use and modify for educational purposes.

## 🌟 What Makes This Special

### Traditional SaaS vs Multi-Tenant

| Feature | Traditional SaaS | Multi-Tenant STEM Builder |
|----------|------------------|-------------------------|
| Infrastructure Cost | High (shared servers) | $0 (user-owned) |
| Scalability | Limited by shared resources | Unlimited (user limits) |
| Data Privacy | Stored in company database | In your Cloudflare account |
| Vendor Lock-in | Yes | No |
| Cost Control | Subscription required | Pay only for your usage |
| Data Portability | Difficult | Easy (your account) |
| Rate Limits | Shared bottlenecks | Your own generous limits |

### The Vision

We're building more than an app - we're building a **distributed ecosystem** where:

- Users are participants, not just consumers
- Infrastructure scales with users, not against them
- Privacy is built-in, not an afterthought
- Costs are transparent and controlled
- Innovation happens at the edge

## 📚 Documentation

- [CLOUDFLARE_ARCHITECTURE.md](./CLOUDFLARE_ARCHITECTURE.md) - Technical architecture
- [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) - Deploy to Cloudflare Pages
- [MULTI_TENANT_GUIDE.md](./MULTI_TENANT_GUIDE.md) - User guide
- [cloudflare-workers/DEPLOYMENT.md](./cloudflare-workers/DEPLOYMENT.md) - Deploy Worker

## 🔗 Links

- Cloudflare: https://cloudflare.com
- Cloudflare Workers: https://developers.cloudflare.com/workers
- Cloudflare Pages: https://developers.cloudflare.com/pages
- Workers AI: https://developers.cloudflare.com/workers-ai

---

**Built with ❤️ for the next generation of engineers. Powered by Cloudflare and AI.**

**Revolutionizing SaaS with multi-tenant, user-controlled architecture.** 🚀
