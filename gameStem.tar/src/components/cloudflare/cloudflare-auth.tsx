'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Cloud, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'
import { useState, useEffect } from 'react'
import { toast } from 'sonner'

interface CloudflareAuthProps {
  onConnected?: (workerUrl: string) => void
}

export function CloudflareAuth({ onConnected }: CloudflareAuthProps) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'connected' | 'error'>('idle')
  const [workerUrl, setWorkerUrl] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    checkConnectionStatus()
  }, [])

  const checkConnectionStatus = async () => {
    try {
      const response = await fetch('/api/cloudflare/account')
      const data = await response.json()

      if (data.connected) {
        setStatus('connected')
        toast.success('Connected to Cloudflare', {
          description: `Logged in as ${data.user.email}`
        })
      }
    } catch (err) {
      setStatus('idle')
    }
  }

  const handleCloudflareLogin = () => {
    window.location.href = '/api/cloudflare/auth'
  }

  const handleDisconnect = async () => {
    try {
      await fetch('/api/cloudflare/account', { method: 'DELETE' })
      setStatus('idle')
      toast.success('Disconnected from Cloudflare')
    } catch (err) {
      toast.error('Failed to disconnect')
    }
  }

  const handleSaveWorkerUrl = () => {
    if (!workerUrl.trim()) {
      toast.error('Please enter a Worker URL')
      return
    }

    try {
      localStorage.setItem('cf_worker_url', workerUrl.trim())
      onConnected?.(workerUrl.trim())
      toast.success('Worker URL saved', {
        description: 'Your Cloudflare Worker is now connected'
      })
    } catch (err) {
      toast.error('Failed to save Worker URL')
    }
  }

  if (status === 'connected') {
    return (
      <Card className="border-green-500/50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <CardTitle>Cloudflare Connected</CardTitle>
          </div>
          <CardDescription>
            Your Cloudflare account is linked and ready to use
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="worker-url">Cloudflare Worker URL</Label>
            <Input
              id="worker-url"
              placeholder="https://your-worker.workers.dev"
              value={workerUrl}
              onChange={(e) => setWorkerUrl(e.target.value)}
              className="mt-1"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Enter your deployed Cloudflare Worker URL to enable AI features
            </p>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSaveWorkerUrl} className="flex-1">
              Save Worker URL
            </Button>
            <Button onClick={handleDisconnect} variant="outline">
              Disconnect
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Cloud className="w-5 h-5 text-orange-500" />
          <CardTitle>Connect Cloudflare</CardTitle>
        </div>
        <CardDescription>
          Connect your Cloudflare account to use your own AI, storage, and database resources
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-start gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <span>Use your own Cloudflare Workers AI for chatbot</span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <span>Store projects in your Cloudflare R2 bucket</span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <span>Learn your preferences with Vector DB</span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <span>Unlimited scalability with your account limits</span>
          </div>
        </div>

        <Button
          onClick={handleCloudflareLogin}
          className="w-full"
          disabled={status === 'loading'}
        >
          {status === 'loading' ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              <Cloud className="w-4 h-4 mr-2" />
              Connect with Cloudflare
            </>
          )}
        </Button>

        <div className="pt-4 border-t">
          <h4 className="text-sm font-medium mb-2">Don't have a Worker?</h4>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open('/cloudflare-workers/DEPLOYMENT.md', '_blank')}
          >
            <Cloud className="w-4 h-4 mr-2" />
            Deploy Worker Guide
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
