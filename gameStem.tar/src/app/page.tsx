'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import {
  Settings,
  Play,
  Save,
  FolderOpen,
  Plus,
  MessageSquare,
  Zap,
  Cpu,
  Gauge,
  Wifi,
  Battery,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  Layers,
  Code2,
  Share2,
  X
} from 'lucide-react'

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [chatOpen, setChatOpen] = useState(true)
  const [detailLevel, setDetailLevel] = useState(1) // 1=visual, 2=wiring, 3=code
  const [simulationRunning, setSimulationRunning] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', content: 'Welcome to STEM Builder! I\'m your AI assistant. You can ask me to create new components, help with challenges, or explain how parts work together. What would you like to build today?' }
  ])
  const [currentInput, setCurrentInput] = useState('')
  const [apiConfig, setApiConfig] = useState({
    llmModel: 'gpt-4',
    imageModel: 'dall-e-3'
  })

  const components = [
    { id: 1, name: 'ESP32 Microcontroller', category: 'controller', icon: <Cpu className="w-8 h-8" />, color: 'bg-blue-500' },
    { id: 2, name: 'Jetson Nano', category: 'controller', icon: <Zap className="w-8 h-8" />, color: 'bg-purple-500' },
    { id: 3, name: 'DC Motor', category: 'actuator', icon: <Gauge className="w-8 h-8" />, color: 'bg-green-500' },
    { id: 4, name: 'Servo Motor', category: 'actuator', icon: <Gauge className="w-8 h-8" />, color: 'bg-green-600' },
    { id: 5, name: 'Wheel', category: 'actuator', icon: <Layers className="w-8 h-8" />, color: 'bg-orange-500' },
    { id: 6, name: 'LED', category: 'actuator', icon: <Zap className="w-8 h-8" />, color: 'bg-yellow-500' },
    { id: 7, name: 'Temperature Sensor', category: 'sensor', icon: <Gauge className="w-8 h-8" />, color: 'bg-red-500' },
    { id: 8, name: 'Motion Sensor', category: 'sensor', icon: <Eye className="w-8 h-8" />, color: 'bg-pink-500' },
    { id: 9, name: 'Ultrasonic Sensor', category: 'sensor', icon: <Zap className="w-8 h-8" />, color: 'bg-cyan-500' },
    { id: 10, name: 'Push Button', category: 'input', icon: <Zap className="w-8 h-8" />, color: 'bg-gray-500' },
    { id: 11, name: 'Toggle Switch', category: 'input', icon: <Layers className="w-8 h-8" />, color: 'bg-gray-600' },
    { id: 12, name: 'Battery Pack', category: 'power', icon: <Battery className="w-8 h-8" />, color: 'bg-emerald-500' },
    { id: 13, name: 'WiFi Module', category: 'communication', icon: <Wifi className="w-8 h-8" />, color: 'bg-indigo-500' },
    { id: 14, name: 'Bluetooth Module', category: 'communication', icon: <Share2 className="w-8 h-8" />, color: 'bg-blue-600' },
  ]

  const categoryColors: Record<string, string> = {
    controller: 'bg-blue-500/20 text-blue-700 dark:text-blue-300',
    sensor: 'bg-red-500/20 text-red-700 dark:text-red-300',
    actuator: 'bg-green-500/20 text-green-700 dark:text-green-300',
    input: 'bg-gray-500/20 text-gray-700 dark:text-gray-300',
    power: 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300',
    communication: 'bg-indigo-500/20 text-indigo-700 dark:text-indigo-300',
  }

  const groupedComponents = components.reduce((acc, comp) => {
    if (!acc[comp.category]) {
      acc[comp.category] = []
    }
    acc[comp.category].push(comp)
    return acc
  }, {} as Record<string, typeof components>)

  const sendMessage = async () => {
    if (!currentInput.trim()) return

    const userMessage = { role: 'user' as const, content: currentInput }
    setChatMessages(prev => [...prev, userMessage])
    setCurrentInput('')

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...chatMessages, userMessage] })
      })

      if (!response.ok) throw new Error('Failed to get response')

      const data = await response.json()
      const aiResponse = data.message

      setChatMessages(prev => [...prev, aiResponse])
    } catch (error) {
      console.error('Chat error:', error)
      const errorMessage = {
        role: 'assistant' as const,
        content: 'Sorry, I had trouble connecting. Please try again.'
      }
      setChatMessages(prev => [...prev, errorMessage])
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Zap className="w-8 h-8 text-orange-500" />
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                  STEM Builder
                </h1>
                <p className="text-xs text-muted-foreground">AI-Powered Construction Game</p>
              </div>
            </div>
            <Separator orientation="vertical" className="h-8" />
            <div className="flex items-center gap-2">
              <Input
                placeholder="Project name..."
                defaultValue="My First Robot"
                className="w-64"
              />
              <Button variant="outline" size="sm">
                <FolderOpen className="w-4 h-4 mr-2" />
                Open
              </Button>
              <Button size="sm">
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Detail Level Control */}
            <div className="flex items-center gap-2 bg-muted rounded-lg p-2">
              <span className="text-xs font-medium">Detail Level:</span>
              <div className="flex gap-1">
                <Button
                  variant={detailLevel === 1 ? 'default' : 'ghost'}
                  size="sm"
                  className="h-7 px-2"
                  onClick={() => setDetailLevel(1)}
                >
                  <Eye className="w-3 h-3 mr-1" />
                  Visual
                </Button>
                <Button
                  variant={detailLevel === 2 ? 'default' : 'ghost'}
                  size="sm"
                  className="h-7 px-2"
                  onClick={() => setDetailLevel(2)}
                >
                  <Share2 className="w-3 h-3 mr-1" />
                  Wiring
                </Button>
                <Button
                  variant={detailLevel === 3 ? 'default' : 'ghost'}
                  size="sm"
                  className="h-7 px-2"
                  onClick={() => setDetailLevel(3)}
                >
                  <Code2 className="w-3 h-3 mr-1" />
                  Code
                </Button>
              </div>
            </div>

            <Separator orientation="vertical" className="h-8" />

            {/* Simulation Control */}
            <Button
              variant={simulationRunning ? 'destructive' : 'default'}
              size="sm"
              onClick={() => setSimulationRunning(!simulationRunning)}
            >
              {simulationRunning ? (
                <>
                  <span className="mr-2">Stop</span>
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Simulate
                </>
              )}
            </Button>

            <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon">
                  <Settings className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>API Configuration</DialogTitle>
                  <DialogDescription>
                    Configure your AI chatbot and image generation APIs. These settings allow you to use your own AI services.
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-6 py-4">
                  {/* LLM Configuration */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <MessageSquare className="w-5 h-5" />
                      LLM Chatbot Configuration
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="llm-api-endpoint">LLM API Endpoint</Label>
                        <Input
                          id="llm-api-endpoint"
                          placeholder="https://api.openai.com/v1"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Leave empty to use the default endpoint
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="llm-api-key">LLM API Key</Label>
                        <Input
                          id="llm-api-key"
                          type="password"
                          placeholder="sk-..."
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Your API key will be stored securely
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="llm-model">LLM Model</Label>
                        <Input
                          id="llm-model"
                          value={apiConfig.llmModel}
                          onChange={(e) => setApiConfig({ ...apiConfig, llmModel: e.target.value })}
                          placeholder="gpt-4"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Examples: gpt-4, gpt-3.5-turbo, claude-3-opus
                        </p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Image Generation Configuration */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Image Generation Configuration
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="image-api-endpoint">Image API Endpoint</Label>
                        <Input
                          id="image-api-endpoint"
                          placeholder="https://api.openai.com/v1"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Leave empty to use the default endpoint
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="image-api-key">Image API Key</Label>
                        <Input
                          id="image-api-key"
                          type="password"
                          placeholder="sk-..."
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Your API key will be stored securely
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="image-model">Image Model</Label>
                        <Input
                          id="image-model"
                          value={apiConfig.imageModel}
                          onChange={(e) => setApiConfig({ ...apiConfig, imageModel: e.target.value })}
                          placeholder="dall-e-3"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Examples: dall-e-3, dall-e-2, stable-diffusion
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setSettingsOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => {
                    setSettingsOpen(false)
                    // TODO: Save config to API
                  }}>
                    Save Configuration
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Sidebar Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>

            {/* Chat Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setChatOpen(!chatOpen)}
            >
              <MessageSquare className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Component Library Sidebar */}
        {sidebarOpen && (
          <aside className="w-80 border-r bg-card overflow-hidden flex flex-col">
            <div className="p-4 border-b">
              <h2 className="font-semibold text-lg mb-2">Component Library</h2>
              <Input placeholder="Search components..." className="text-sm" />
            </div>
            <ScrollArea className="flex-1 p-4">
              <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                  <TabsTrigger value="custom" className="text-xs">Custom</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="space-y-4">
                  {Object.entries(groupedComponents).map(([category, comps]) => (
                    <div key={category}>
                      <Badge variant="secondary" className="mb-2 capitalize text-xs">
                        {category}
                      </Badge>
                      <div className="grid grid-cols-1 gap-2">
                        {comps.map((comp) => (
                          <Card
                            key={comp.id}
                            className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-primary/50"
                          >
                            <CardContent className="p-3">
                              <div className="flex items-center gap-3">
                                <div className={`${comp.color} text-white rounded-lg p-2 flex-shrink-0`}>
                                  {comp.icon}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-sm font-medium truncate">{comp.name}</h4>
                                  <p className="text-xs text-muted-foreground capitalize">{comp.category}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="custom" className="space-y-2">
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6 text-center">
                      <Plus className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Create custom component with AI</p>
                      <Button className="mt-2 w-full" size="sm">
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Ask AI to Create
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </ScrollArea>
          </aside>
        )}

        {/* Canvas Area */}
        <main className="flex-1 relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern">
            {/* Grid background */}
            <div className="w-full h-full" style={{
              backgroundImage: `
                linear-gradient(to right, rgba(0,0,0,0.05) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(0,0,0,0.05) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px'
            }} />
          </div>

          {/* Canvas Toolbar */}
          <div className="absolute top-4 left-4 right-4 z-10">
            <div className="flex gap-2">
              <Button variant="secondary" size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Component
              </Button>
              <Button variant="secondary" size="sm">
                <Layers className="w-4 h-4 mr-2" />
                Layers
              </Button>
              <Button variant="secondary" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Connect
              </Button>
              <div className="flex-1" />
              <Badge variant="outline" className="h-9">
                Components: 0
              </Badge>
              <Badge variant="outline" className="h-9">
                Connections: 0
              </Badge>
            </div>
          </div>

          {/* Empty State */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Card className="max-w-md p-8 text-center">
              <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Plus className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Start Building!</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Drag components from the library or use the chatbot to create custom parts.
                Your project will progressively show more details as you explore.
              </p>
              <div className="flex gap-2 justify-center">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Component
                </Button>
                <Button variant="outline">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Ask AI for Help
                </Button>
              </div>
            </Card>
          </div>

          {/* Detail Level Indicator */}
          {detailLevel > 1 && (
            <div className="absolute bottom-4 left-4 z-10">
              <Badge variant="secondary" className="text-sm px-3 py-1">
                {detailLevel === 2 && '🔌 Showing wiring connections'}
                {detailLevel === 3 && '💻 Showing code snippets'}
              </Badge>
            </div>
          )}
        </main>

        {/* Chat Panel */}
        {chatOpen && (
          <aside className="w-96 border-l bg-card overflow-hidden flex flex-col">
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                <h2 className="font-semibold">AI Assistant</h2>
              </div>
              <Badge variant="secondary" className="text-xs">LLM Ready</Badge>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {chatMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Ask me to create components, explain how parts work, or suggest projects..."
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault()
                      sendMessage()
                    }
                  }}
                  className="min-h-[80px] resize-none"
                />
              </div>
              <div className="flex gap-2 mt-2">
                <Button onClick={sendMessage} disabled={!currentInput.trim()} className="flex-1">
                  Send
                </Button>
                <Button variant="outline" size="icon">
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  )
}
