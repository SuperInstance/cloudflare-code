import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Predefined components for the library
const defaultComponents = [
  {
    name: 'ESP32 Microcontroller',
    category: 'controller',
    description: 'A powerful microcontroller with WiFi and Bluetooth capabilities, perfect for IoT projects.',
    type: 'esp32',
    pins: JSON.stringify([
      { name: 'GPIO1', type: 'digital' },
      { name: 'GPIO2', type: 'digital' },
      { name: 'GPIO3', type: 'digital' },
      { name: 'GPIO4', type: 'pwm' },
      { name: 'ADC1', type: 'analog' },
      { name: 'ADC2', type: 'analog' },
      { name: '3V3', type: 'power' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 80, height: 100 }),
    isCustom: false
  },
  {
    name: 'Jetson Nano',
    category: 'controller',
    description: 'An AI-powered computer for edge computing, perfect for computer vision projects.',
    type: 'jetson',
    pins: JSON.stringify([
      { name: 'GPIO7', type: 'digital' },
      { name: 'GPIO11', type: 'digital' },
      { name: 'GPIO13', type: 'pwm' },
      { name: 'GPIO15', type: 'pwm' },
      { name: '5V', type: 'power' },
      { name: '3V3', type: 'power' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 120, height: 120 }),
    isCustom: false
  },
  {
    name: 'DC Motor',
    category: 'actuator',
    description: 'A basic DC motor for rotational movement. Requires motor driver for control.',
    type: 'motor-dc',
    pins: JSON.stringify([
      { name: '+', type: 'power' },
      { name: '-', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 60, height: 80 }),
    isCustom: false
  },
  {
    name: 'Servo Motor',
    category: 'actuator',
    description: 'A servo motor for precise angular positioning. Great for robotic arms and steering.',
    type: 'motor-servo',
    pins: JSON.stringify([
      { name: 'Signal', type: 'pwm' },
      { name: 'VCC', type: 'power' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 40, height: 60 }),
    isCustom: false
  },
  {
    name: 'Wheel',
    category: 'actuator',
    description: 'A wheel for mobile robots. Attaches to motors for movement.',
    type: 'wheel',
    pins: JSON.stringify([]),
    dimensions: JSON.stringify({ width: 60, height: 60 }),
    isCustom: false
  },
  {
    name: 'LED',
    category: 'actuator',
    description: 'A light-emitting diode for visual indicators and lighting effects.',
    type: 'led',
    pins: JSON.stringify([
      { name: 'Anode (+)', type: 'power' },
      { name: 'Cathode (-)', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 20, height: 40 }),
    isCustom: false
  },
  {
    name: 'Temperature Sensor',
    category: 'sensor',
    description: 'Measures temperature in Celsius and Fahrenheit. Great for climate monitoring.',
    type: 'sensor-temperature',
    pins: JSON.stringify([
      { name: 'VCC', type: 'power' },
      { name: 'Data', type: 'digital' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 30, height: 50 }),
    isCustom: false
  },
  {
    name: 'Motion Sensor (PIR)',
    category: 'sensor',
    description: 'Detects motion using infrared. Perfect for security and automation projects.',
    type: 'sensor-motion',
    pins: JSON.stringify([
      { name: 'VCC', type: 'power' },
      { name: 'OUT', type: 'digital' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 40, height: 40 }),
    isCustom: false
  },
  {
    name: 'Ultrasonic Sensor',
    category: 'sensor',
    description: 'Measures distance using sound waves. Great for obstacle detection and robotics.',
    type: 'sensor-ultrasonic',
    pins: JSON.stringify([
      { name: 'VCC', type: 'power' },
      { name: 'Trig', type: 'digital' },
      { name: 'Echo', type: 'digital' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 50, height: 30 }),
    isCustom: false
  },
  {
    name: 'Push Button',
    category: 'input',
    description: 'A momentary push button for user input and triggering events.',
    type: 'button-push',
    pins: JSON.stringify([
      { name: '1', type: 'digital' },
      { name: '2', type: 'digital' }
    ]),
    dimensions: JSON.stringify({ width: 30, height: 30 }),
    isCustom: false
  },
  {
    name: 'Toggle Switch',
    category: 'input',
    description: 'A mechanical toggle switch for on/off control.',
    type: 'switch-toggle',
    pins: JSON.stringify([
      { name: '1', type: 'power' },
      { name: '2', type: 'power' }
    ]),
    dimensions: JSON.stringify({ width: 40, height: 40 }),
    isCustom: false
  },
  {
    name: 'Battery Pack',
    category: 'power',
    description: 'Provides power to your projects. Rechargeable and reliable.',
    type: 'battery',
    pins: JSON.stringify([
      { name: '+', type: 'power' },
      { name: '-', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 80, height: 50 }),
    isCustom: false
  },
  {
    name: 'WiFi Module',
    category: 'communication',
    description: 'Enables wireless connectivity for IoT projects and remote control.',
    type: 'wifi',
    pins: JSON.stringify([
      { name: 'RX', type: 'digital' },
      { name: 'TX', type: 'digital' },
      { name: 'VCC', type: 'power' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 40, height: 60 }),
    isCustom: false
  },
  {
    name: 'Bluetooth Module',
    category: 'communication',
    description: 'Short-range wireless communication for mobile device integration.',
    type: 'bluetooth',
    pins: JSON.stringify([
      { name: 'RX', type: 'digital' },
      { name: 'TX', type: 'digital' },
      { name: 'VCC', type: 'power' },
      { name: 'GND', type: 'ground' }
    ]),
    dimensions: JSON.stringify({ width: 40, height: 60 }),
    isCustom: false
  }
]

// GET all components
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const isCustom = searchParams.get('custom')

    // Check if components exist in database
    const dbComponents = await db.componentLibrary.findMany({
      where: {
        ...(category && { category }),
        ...(isCustom !== null && { isCustom: isCustom === 'true' })
      },
      orderBy: { name: 'asc' }
    })

    // If database is empty, initialize with default components
    if (dbComponents.length === 0) {
      for (const comp of defaultComponents) {
        await db.componentLibrary.create({
          data: comp
        })
      }

      // Fetch again after initialization
      const initializedComponents = await db.componentLibrary.findMany({
        where: {
          ...(category && { category }),
          ...(isCustom !== null && { isCustom: isCustom === 'true' })
        },
        orderBy: { name: 'asc' }
      })

      return NextResponse.json(initializedComponents)
    }

    return NextResponse.json(dbComponents)
  } catch (error) {
    console.error('Error fetching components:', error)
    return NextResponse.json(
      { error: 'Failed to fetch components' },
      { status: 500 }
    )
  }
}

// POST create custom component
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, category, description, type, imageUrl } = body

    if (!name || !category || !description || !type) {
      return NextResponse.json(
        { error: 'name, category, description, and type are required' },
        { status: 400 }
      )
    }

    const component = await db.componentLibrary.create({
      data: {
        name,
        category,
        description,
        type,
        imageUrl: imageUrl || null,
        pins: JSON.stringify([]),
        dimensions: JSON.stringify({ width: 60, height: 60 }),
        isCustom: true
      }
    })

    return NextResponse.json(component)
  } catch (error) {
    console.error('Error creating component:', error)
    return NextResponse.json(
      { error: 'Failed to create component' },
      { status: 500 }
    )
  }
}
