import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, componentType, category } = body

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      )
    }

    // Build enhanced prompt for STEM components
    const enhancedPrompt = `Professional technical illustration of a ${componentType || 'electronic component'} for STEM education. ${prompt}. Clean white background, isometric view, educational diagram style, high detail, labeled pins clearly visible.`

    // Initialize z-ai SDK
    const zai = await ZAI.create()

    // Generate image
    const response = await zai.images.generations.create({
      prompt: enhancedPrompt,
      size: '1024x1024'
    })

    const imageBase64 = response.data[0]?.base64

    if (!imageBase64) {
      throw new Error('No image data received from API')
    }

    // Ensure public/generated-components directory exists
    const publicDir = join(process.cwd(), 'public', 'generated-components')
    if (!existsSync(publicDir)) {
      await mkdir(publicDir, { recursive: true })
    }

    // Save image to public directory
    const filename = `${componentType || 'component'}-${Date.now()}.png`
    const filepath = join(publicDir, filename)

    // Decode base64 and save
    const buffer = Buffer.from(imageBase64, 'base64')
    await writeFile(filepath, buffer)

    // Return the URL path
    const imageUrl = `/generated-components/${filename}`

    return NextResponse.json({
      success: true,
      imageUrl,
      filename,
      prompt: enhancedPrompt
    })
  } catch (error) {
    console.error('Image generation error:', error)
    return NextResponse.json(
      {
        error: 'Failed to generate image',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
