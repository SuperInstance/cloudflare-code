import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET user config
export async function GET(request: NextRequest) {
  try {
    // For now, use a default user ID. In production, this would come from auth
    const userId = 'default-user'

    let config = await db.userConfig.findUnique({
      where: { userId }
    })

    if (!config) {
      // Create default config
      config = await db.userConfig.create({
        data: {
          userId,
          llmModel: 'gpt-4',
          imageModel: 'dall-e-3',
          theme: 'dark'
        }
      })
    }

    // Don't expose API keys in response
    const { llmApiKey, imageApiKey, ...safeConfig } = config

    return NextResponse.json(safeConfig)
  } catch (error) {
    console.error('Error fetching config:', error)
    return NextResponse.json(
      { error: 'Failed to fetch configuration' },
      { status: 500 }
    )
  }
}

// POST update user config
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      llmApiEndpoint,
      llmApiKey,
      llmModel,
      imageApiEndpoint,
      imageApiKey,
      imageModel,
      theme
    } = body

    // For now, use a default user ID. In production, this would come from auth
    const userId = 'default-user'

    const config = await db.userConfig.upsert({
      where: { userId },
      update: {
        llmApiEndpoint: llmApiEndpoint || null,
        llmApiKey: llmApiKey || null,
        llmModel: llmModel || 'gpt-4',
        imageApiEndpoint: imageApiEndpoint || null,
        imageApiKey: imageApiKey || null,
        imageModel: imageModel || 'dall-e-3',
        theme: theme || 'dark'
      },
      create: {
        userId,
        llmApiEndpoint: llmApiEndpoint || null,
        llmApiKey: llmApiKey || null,
        llmModel: llmModel || 'gpt-4',
        imageApiEndpoint: imageApiEndpoint || null,
        imageApiKey: imageApiKey || null,
        imageModel: imageModel || 'dall-e-3',
        theme: theme || 'dark'
      }
    })

    // Don't expose API keys in response
    const { llmApiKey: _, imageApiKey: __, ...safeConfig } = config

    return NextResponse.json(safeConfig)
  } catch (error) {
    console.error('Error updating config:', error)
    return NextResponse.json(
      { error: 'Failed to update configuration' },
      { status: 500 }
    )
  }
}
