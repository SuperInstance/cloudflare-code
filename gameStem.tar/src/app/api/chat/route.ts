import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'

const SYSTEM_PROMPT = `You are an expert STEM educator and electrical engineering assistant for a gamified construction game called "STEM Builder".

Your role is to help players:
1. Create and design custom components for their projects
2. Understand how components work together
3. Suggest project ideas and challenges
4. Explain electrical and mechanical concepts in simple terms
5. Provide guidance on wiring and code generation when players explore deeper

When a user asks for custom components:
- Suggest realistic components that would work in real STEM projects
- Describe their appearance, function, and typical uses
- Mention how they might connect to other components (sensors, controllers, actuators)
- Keep descriptions imaginative but grounded in real physics/engineering

When explaining concepts:
- Use simple language appropriate for the player's apparent level
- Provide practical examples
- Encourage experimentation and learning

The game has a progressive detail system:
- Visual level: Components appear and work visually
- Wiring level: Wiring connections are shown
- Code level: Code snippets are generated

Always be encouraging, creative, and educational!`

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { messages } = body

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Messages array is required' },
        { status: 400 }
      )
    }

    // Get user config for custom API settings
    const userId = 'default-user'
    const config = await db.userConfig.findUnique({
      where: { userId }
    })

    // Prepare messages with system prompt
    const apiMessages = [
      {
        role: 'assistant',
        content: SYSTEM_PROMPT
      },
      ...messages
    ]

    // Call LLM using z-ai-web-dev-sdk
    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: apiMessages,
      thinking: { type: 'disabled' }
    })

    const response = completion.choices[0]?.message?.content

    if (!response) {
      throw new Error('Empty response from AI')
    }

    return NextResponse.json({
      message: {
        role: 'assistant',
        content: response
      }
    })
  } catch (error) {
    console.error('Chat API error:', error)
    return NextResponse.json(
      {
        error: 'Failed to generate response',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
