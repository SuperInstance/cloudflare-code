import { NextRequest, NextResponse } from 'next/server'

// Cloudflare OAuth Configuration
const CLOUDFLARE_CLIENT_ID = process.env.CLOUDFLARE_CLIENT_ID || ''
const CLOUDFLARE_CLIENT_SECRET = process.env.CLOUDFLARE_CLIENT_SECRET || ''
const REDIRECT_URI = process.env.CLOUDFLARE_REDIRECT_URI || 'http://localhost:3000/api/cloudflare/callback'

// Cloudflare OAuth endpoints
const AUTH_URL = 'https://dash.cloudflare.com/oauth2/auth'
const TOKEN_URL = 'https://dash.cloudflare.com/oauth2/token'
const USER_URL = 'https://api.cloudflare.com/client/v4/user'

export async function GET(request: NextRequest) {
  try {
    // Check if client ID is configured
    if (!CLOUDFLARE_CLIENT_ID) {
      return NextResponse.json(
        {
          error: 'Cloudflare OAuth not configured',
          message: 'Please set CLOUDFLARE_CLIENT_ID environment variable'
        },
        { status: 500 }
      )
    }

    // Generate state parameter for CSRF protection
    const state = crypto.randomUUID()

    // Construct OAuth authorization URL
    const authUrl = new URL(AUTH_URL)
    authUrl.searchParams.set('client_id', CLOUDFLARE_CLIENT_ID)
    authUrl.searchParams.set('redirect_uri', REDIRECT_URI)
    authUrl.searchParams.set('response_type', 'code')
    authUrl.searchParams.set('scope', 'account:read')
    authUrl.searchParams.set('state', state)

    // Store state in a cookie for verification
    const response = NextResponse.redirect(authUrl.toString())
    response.cookies.set('cf_oauth_state', state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 600 // 10 minutes
    })

    return response
  } catch (error) {
    console.error('OAuth error:', error)
    return NextResponse.json(
      { error: 'Failed to initiate OAuth flow' },
      { status: 500 }
    )
  }
}
