import { NextRequest, NextResponse } from 'next/server'

const USER_URL = 'https://api.cloudflare.com/client/v4/user'

export async function GET(request: NextRequest) {
  try {
    const accessToken = request.cookies.get('cf_access_token')

    if (!accessToken) {
      return NextResponse.json(
        { connected: false },
        { status: 401 }
      )
    }

    // Get user info
    const userResponse = await fetch(USER_URL, {
      headers: {
        'Authorization': `Bearer ${accessToken.value}`
      }
    })

    if (!userResponse.ok) {
      if (userResponse.status === 401) {
        return NextResponse.json(
          { connected: false, error: 'expired_token' },
          { status: 401 }
        )
      }
      throw new Error('Failed to fetch user info')
    }

    const userData = await userResponse.json()

    return NextResponse.json({
      connected: true,
      user: {
        id: userData.result.id,
        email: userData.result.email,
        username: userData.result.username
      }
    })
  } catch (error) {
    console.error('Account check error:', error)
    return NextResponse.json(
      { connected: false, error: 'server_error' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  const response = NextResponse.json({ disconnected: true })

  // Clear all Cloudflare cookies
  response.cookies.delete('cf_access_token')
  response.cookies.delete('cf_refresh_token')
  response.cookies.delete('cf_user_id')
  response.cookies.delete('cf_user_email')

  return response
}
