import { NextRequest, NextResponse } from 'next/server'

const CLOUDFLARE_CLIENT_ID = process.env.CLOUDFLARE_CLIENT_ID || ''
const CLOUDFLARE_CLIENT_SECRET = process.env.CLOUDFLARE_CLIENT_SECRET || ''
const REDIRECT_URI = process.env.CLOUDFLARE_REDIRECT_URI || 'http://localhost:3000/api/cloudflare/callback'
const TOKEN_URL = 'https://dash.cloudflare.com/oauth2/token'
const USER_URL = 'https://api.cloudflare.com/client/v4/user'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const code = searchParams.get('code')
    const state = searchParams.get('state')
    const error = searchParams.get('error')

    // Check for OAuth errors
    if (error) {
      return NextResponse.redirect(
        new URL('/?error=' + encodeURIComponent(error), request.url)
      )
    }

    // Validate state parameter
    const storedState = request.cookies.get('cf_oauth_state')
    if (!state || state !== storedState?.value) {
      return NextResponse.redirect(
        new URL('/?error=invalid_state', request.url)
      )
    }

    if (!code) {
      return NextResponse.redirect(
        new URL('/?error=no_code', request.url)
      )
    }

    // Exchange authorization code for access token
    const tokenResponse = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        client_id: CLOUDFLARE_CLIENT_ID,
        client_secret: CLOUDFLARE_CLIENT_SECRET,
        code: code,
        grant_type: 'authorization_code',
        redirect_uri: REDIRECT_URI
      })
    })

    if (!tokenResponse.ok) {
      const errorData = await tokenResponse.text()
      console.error('Token exchange error:', errorData)
      return NextResponse.redirect(
        new URL('/?error=token_exchange_failed', request.url)
      )
    }

    const tokenData = await tokenResponse.json()
    const accessToken = tokenData.access_token
    const refreshToken = tokenData.refresh_token

    // Get user info
    const userResponse = await fetch(USER_URL, {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    })

    if (!userResponse.ok) {
      console.error('User info error:', await userResponse.text())
      return NextResponse.redirect(
        new URL('/?error=user_info_failed', request.url)
      )
    }

    const userData = await userResponse.json()

    // Create session response
    const response = NextResponse.redirect(new URL('/?connected=true', request.url))

    // Store tokens in secure cookies
    response.cookies.set('cf_access_token', accessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 3600 // 1 hour
    })

    response.cookies.set('cf_refresh_token', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 2592000 // 30 days
    })

    // Store user info
    response.cookies.set('cf_user_id', userData.result.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 2592000
    })

    response.cookies.set('cf_user_email', userData.result.email, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 2592000
    })

    // Clear state cookie
    response.cookies.delete('cf_oauth_state')

    return response
  } catch (error) {
    console.error('Callback error:', error)
    return NextResponse.redirect(
      new URL('/?error=server_error', request.url)
    )
  }
}
