# 🌍 Deploy STEM Builder to Cloudflare Pages

This guide will walk you through deploying STEM Builder to your Cloudflare account on a custom domain.

## Overview

STEM Builder is now designed as a **multi-tenant portal** that:
- Frontend runs on Cloudflare Pages (your domain)
- Each user connects their own Cloudflare account
- Users deploy a personal Worker that provides AI, storage, and database
- Zero infrastructure cost for the app itself
- Infinite scalability through user-owned resources

## Prerequisites

- Cloudflare account (free): https://dash.cloudflare.com/sign-up
- Custom domain (e.g., stem-builder.yourdomain.com)
- Node.js 18+ installed
- Wrangler CLI installed: `npm install -g wrangler`

## Step 1: Set Up Cloudflare OAuth

### 1.1 Create OAuth App

1. Go to https://dash.cloudflare.com/profile/api-tokens
2. Click "Create Token"
3. Select "Create Custom Token"
4. Configure:
   ```
   Token name: STEM Builder
   Permissions:
     - Account - Cloudflare Workers - Edit
     - Account - Account Settings - Read
   ```
5. Click "Continue to summary"
6. Copy the values (you'll need them):
   - Client ID
   - Client Secret

### 1.2 Configure Environment Variables

Create `.env.local` in the project root:

```bash
CLOUDFLARE_CLIENT_ID=your_client_id_here
CLOUDFLARE_CLIENT_SECRET=your_client_secret_here
CLOUDFLARE_REDIRECT_URI=https://your-domain.com/api/cloudflare/callback
```

## Step 2: Deploy Frontend to Cloudflare Pages

### 2.1 Create GitHub Repository

1. Push your code to GitHub
2. Ensure `.gitignore` excludes `.env.local`

### 2.2 Create Cloudflare Pages Project

1. Go to Cloudflare Dashboard → Workers & Pages → Create application
2. Select "Pages"
3. Choose "Connect to Git"
4. Select your GitHub repository
5. Configure build settings:
   ```
   Build command: bun run build
   Build output directory: .next
   Root directory: /
   ```
6. Add environment variables:
   - CLOUDFLARE_CLIENT_ID
   - CLOUDFLARE_CLIENT_SECRET
   - CLOUDFLARE_REDIRECT_URI (set to your final URL)
7. Click "Save and Deploy"

### 2.3 Configure Custom Domain

1. In Pages project, go to Custom Domains
2. Click "Set up a custom domain"
3. Enter your domain (e.g., stem-builder.yourdomain.com)
4. Cloudflare will show DNS records to add

Add these DNS records to your domain registrar:

```
Type: CNAME
Name: stem-builder (or your subdomain)
Value: your-project.pages.dev
TTL: 3600
```

Wait for DNS propagation (usually 5-10 minutes).

### 2.4 Update Redirect URI

Once you know the final URL, update:
1. Cloudflare Dashboard → API Tokens
2. Edit your STEM Builder token
3. Update Redirect URI to: `https://your-domain.com/api/cloudflare/callback`

## Step 3: Users Deploy Their Workers

Each user needs to deploy a Worker following these instructions (share `cloudflare-workers/DEPLOYMENT.md`):

### Quick Start for Users

```bash
# 1. Login to Cloudflare
wrangler login

# 2. Create D1 database
wrangler d1 create stem-builder-db

# 3. Create R2 bucket
wrangler r2 bucket create stem-builder-storage

# 4. Create KV namespace
wrangler kv:namespace create "STEM_BUILDER_CACHE"

# 5. Create Vectorize index
wrangler vectorize create stem-builder-vectors --dimensions=768 --metric=cosine

# 6. Initialize database
wrangler d1 execute stem-builder-db --file=d1-schema.sql

# 7. Configure worker (edit wrangler.toml with IDs)
# 8. Deploy
wrangler deploy
```

## Step 4: Test Deployment

### 4.1 Test Frontend

Visit your domain: `https://your-domain.com`

Expected:
- STEM Builder loads successfully
- "Connect with Cloudflare" button visible
- No console errors

### 4.2 Test OAuth Flow

1. Click "Connect with Cloudflare"
2. Should redirect to Cloudflare authorization page
3. Authorize the app
4. Should redirect back to your domain
5. Should see "Cloudflare Connected" status

### 4.3 Test User Worker

1. After user deploys their Worker, they enter the URL in settings
2. Test Worker health:
   ```bash
   curl https://user-worker.workers.dev/api/health
   ```
3. Expected response:
   ```json
   {
     "status": "healthy",
     "services": {
       "db": true,
       "storage": true,
       "cache": true,
       "vectors": true,
       "ai": true
     }
   }
   ```

## Step 5: Security Hardening

### 5.1 Enable HSTS

Add to `_headers`:

```toml
[[headers]]
  for = "/*"
  [headers.values]
    Strict-Transport-Security = "max-age=31536000; includeSubDomains"
```

### 5.2 CSP Headers

```toml
Content-Security-Policy = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"
```

### 5.3 Rate Limiting

Consider adding rate limiting in your Worker:

```typescript
const rateLimit = {
  requests: 100,
  window: 60000 // 1 minute
};

// Check KV for rate limiting
const key = `ratelimit:${userId}`;
const count = await env.CACHE.get(key);
if (count && parseInt(count) >= rateLimit.requests) {
  return new Response('Rate limit exceeded', { status: 429 });
}
```

## Step 6: Monitoring

### 6.1 Cloudflare Analytics

Access analytics at:
- Cloudflare Dashboard → Workers & Pages → STEM Builder
- View: Requests, Errors, CPU usage, Edge locations

### 6.2 Worker Logs

```bash
wrangler tail
```

### 6.3 Set Up Alerts

1. Cloudflare Dashboard → Notifications
2. Create alerts for:
   - Worker errors > threshold
   - High CPU usage
   - Rate limit exceeded

## Troubleshooting

### OAuth Callback Fails

**Error**: `redirect_uri_mismatch`

**Solution**:
- Verify CLOUDFLARE_REDIRECT_URI matches exactly
- Include trailing slashes correctly
- Use HTTPS in production

### Worker Not Accessible

**Error**: `CORS error` or `Network error`

**Solution**:
- Ensure Worker has CORS headers
- Check Worker URL is correct
- Verify Worker is deployed and running

### Workers AI Not Working

**Error**: `Model not found` or `Workers AI disabled`

**Solution**:
- Enable Workers AI in Cloudflare Dashboard
- Check account allows AI usage
- Verify model names are correct

### Vector DB Not Ready

**Error**: `Vectorize index not ready`

**Solution**:
- Wait a few minutes after creating index
- Check Vectorize status in dashboard
- Recreate index if needed

## Cost Estimates

### For STEM Builder App (You)
- Cloudflare Pages: **$0** (Free tier)
- Bandwidth: **$0** (Unlimited)
- Total: **$0/month**

### Per User (Their Cost)
**Free Tier**:
- Workers: 100,000 requests/day
- Workers AI: 10,000 neurons/day
- R2: 10GB storage
- D1: 5GB storage + 5M rows/day
- KV: 100k reads/day + 1k writes/day
- Vectorize: 1M vectors + 20k ops/day
- **Cost: $0/month**

**Paid Tier** (if users exceed limits):
- Workers: $0.50/M requests
- Workers AI: $0.0001/1k neurons
- R2: $0.015/GB-month
- D1: $0.50/GB-month + $0.01/M rows

## Architecture Diagram

```
┌─────────────────────────────────────────────┐
│  Cloudflare Pages (Your Domain)          │
│  stem-builder.yourdomain.com             │
└──────────────┬──────────────────────────┘
               │
               ├─→ User A (OAuth)
               │   └─→ A's Worker (A's Resources)
               │
               ├─→ User B (OAuth)
               │   └─→ B's Worker (B's Resources)
               │
               ├─→ User C (OAuth)
               │   └─→ C's Worker (C's Resources)
               │
               └─→ User N (OAuth)
                   └─→ N's Worker (N's Resources)
```

## Next Steps

After deployment:

1. ✅ Test OAuth flow end-to-end
2. ✅ Verify user Worker deployment works
3. ✅ Test AI chatbot functionality
4. ✅ Test image generation
5. ✅ Test project save/load
6. ✅ Monitor usage and set up alerts
7. ✅ Create user documentation
8. ✅ Set up analytics tracking

## Support Resources

- Cloudflare Pages Docs: https://developers.cloudflare.com/pages
- Cloudflare Workers Docs: https://developers.cloudflare.com/workers
- Workers AI: https://developers.cloudflare.com/workers-ai
- OAuth Guide: https://developers.cloudflare.com/fundamentals/api/oauth

Your STEM Builder is now live and ready for users! 🚀
