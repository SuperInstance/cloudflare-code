# 🔧 STEM Builder - AI-Powered Construction Game

A gamified STEM construction platform that uses generative AI to help players build, simulate, and learn about real electronic components and robotics. Inspired by The Incredible Machine and Minecraft, but with real-world components like ESP32, Jetson Nano, motors, sensors, and more.

## 🎮 Game Concept

STEM Builder provides a progressive learning experience where complexity grows with player curiosity:

1. **Visual Level** - Components appear and work visually. Perfect for beginners and creative experimentation.
2. **Wiring Level** - Real wiring connections are revealed. Players learn electrical engineering principles.
3. **Code Level** - Actual code snippets are generated. Advanced users dive into programming.

### Key Features

- **🤖 AI-Powered Components** - Ask the chatbot to create custom components with unique properties
- **🔌 Progressive Detail System** - Game complexity matches player exploration level
- **🎨 Visual Simulation** - Components work mechanically without perfect code implementation
- **📝 Real Wiring & Code** - Deep examination reveals actual connections and code
- **🎯 Educational** - Learn STEM concepts through hands-on building
- **🛠️ Customizable APIs** - Use your own chatbot and image generation services
- **🎮 Challenge System** - Puzzles and adventures to complete

## ✨ Technology Stack

### Core Framework
- **Next.js 15** - React framework with App Router
- **TypeScript 5** - Type-safe development
- **Tailwind CSS 4** - Modern styling
- **shadcn/ui** - Beautiful UI components

### AI & Backend
- **z-ai-web-dev-sdk** - AI chat and image generation
- **Prisma ORM** - Database with SQLite
- **LLM Integration** - Customizable chatbot endpoints
- **Image Generation** - Custom component visuals

### State & Data
- **Zustand** - Client state management
- **TanStack Query** - Server state synchronization
- **React Hook Form** - Form handling

## 🚀 Quick Start

```bash
# Install dependencies
bun install

# Initialize database
bun run db:push

# Start development server
bun run dev

# Run linting
bun run lint
```

Open [http://localhost:3000](http://localhost:3000) to start building!

## 🎮 How to Play

### For Beginners
1. Drag components from the library to the canvas
2. Ask the AI chatbot to create imaginary parts
3. Experiment freely - parts work visually!
4. Learn by doing without worrying about wiring or code

### For Intermediate Players
1. Build projects with real components (ESP32, motors, sensors)
2. Switch to "Wiring" detail level to see connections
3. Learn electrical principles
4. Complete challenges and puzzles

### For Advanced Users
1. Switch to "Code" detail level
2. See actual code snippets for components
3. Modify and understand the code
4. Build complex systems with multiple components

## 🔧 Available Components

### Controllers
- ESP32 Microcontroller
- Jetson Nano

### Actuators
- DC Motor
- Servo Motor
- Wheel
- LED

### Sensors
- Temperature Sensor
- Motion Sensor (PIR)
- Ultrasonic Sensor

### Inputs
- Push Button
- Toggle Switch

### Power
- Battery Pack

### Communication
- WiFi Module
- Bluetooth Module

### Custom Components
- Ask the AI to create any component you imagine!

## 🤖 AI Features

### Chatbot Capabilities
- Create custom components based on descriptions
- Explain how parts work together
- Suggest project ideas
- Provide technical guidance
- Generate code snippets

### Image Generation
- Generate visual representations of custom components
- Create technical illustrations
- Design unique part appearances

## ⚙️ API Configuration

STEM Builder supports fully customizable AI APIs:

1. Click the Settings (⚙️) button in the header
2. Configure your LLM endpoint and API key
3. Configure your image generation endpoint and API key
4. Choose your preferred models
5. Save and start using your own AI services!

### Supported Models

**LLM Models:**
- GPT-4, GPT-3.5-turbo
- Claude 3 (Opus, Sonnet, Haiku)
- Any OpenAI-compatible endpoint

**Image Models:**
- DALL-E 3, DALL-E 2
- Stable Diffusion
- Any OpenAI-compatible image endpoint

## 📁 Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── config/         # API configuration endpoints
│   │   ├── chat/           # LLM chatbot
│   │   ├── components/     # Component library
│   │   └── generate-image/ # Image generation
│   ├── page.tsx           # Main game interface
│   └── layout.tsx         # Root layout
├── components/
│   └── ui/                # shadcn/ui components
├── hooks/                 # Custom React hooks
└── lib/
    ├── db.ts              # Prisma client
    └── utils.ts           # Utility functions

prisma/
└── schema.prisma          # Database schema
```

## 🗄️ Database Schema

The application uses SQLite with Prisma ORM:

- **User** - User accounts
- **UserConfig** - API configurations and preferences
- **Project** - Construction projects
- **ProjectComponent** - Components in projects with detail levels
- **ComponentLibrary** - Available components
- **ChatMessage** - Conversation history

## 🎯 Development Roadmap

### Completed ✅
- [x] Database schema design
- [x] Main game UI layout
- [x] API configuration system
- [x] LLM chatbot integration
- [x] Image generation API
- [x] Frontend-backend connectivity

### In Progress 🚧
- [ ] Component drag-and-drop
- [ ] Canvas construction workspace
- [ ] Visual simulation

### Planned 📋
- [ ] Wiring detail level implementation
- [ ] Code generation system
- [ ] Project save/load
- [ ] WebSocket real-time updates
- [ ] Challenge and puzzle system
- [ ] Adventure mode
- [ ] User authentication

## 🎓 Educational Goals

STEM Builder aims to teach:

1. **Electronics** - Understanding circuits, components, and connections
2. **Programming** - Learning to control hardware with code
3. **Engineering** - Problem-solving and system design
4. **Creativity** - Building unique projects and solutions
5. **Collaboration** - Sharing projects with others (coming soon)

## 🤝 Contributing

This is an educational project aimed at making STEM learning fun and accessible. Ideas, feedback, and contributions are welcome!

## 📝 License

MIT License - Feel free to use and modify for educational purposes.

## 🌟 Acknowledgments

Built with:
- [Next.js](https://nextjs.org)
- [shadcn/ui](https://ui.shadcn.com)
- [z-ai-web-dev-sdk](https://z.ai)
- And many other amazing open-source projects!

---

Built with ❤️ for the next generation of engineers and makers. Powered by AI 🚀
