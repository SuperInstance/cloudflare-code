'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, GraduationCap, CheckCircle, Play, MousePointer2, Zap } from 'lucide-react'
import Link from 'next/link'

export default function BeginnerTutorial() {
  const steps = [
    {
      id: 1,
      title: "Welcome to STEM Builder",
      description: "Learn the basics of building with electronic components",
      icon: <GraduationCap className="w-8 h-8" />,
      color: "bg-green-500",
      topics: [
        "Understanding the interface",
        "Component library overview",
        "Canvas workspace basics"
      ]
    },
    {
      id: 2,
      title: "Drag and Drop Components",
      description: "Learn how to place components on your canvas",
      icon: <MousePointer2 className="w-8 h-8" />,
      color: "bg-blue-500",
      topics: [
        "Selecting components from library",
        "Dragging to canvas",
        "Positioning and rotating"
      ]
    },
    {
      id: 3,
      title: "Create Your First Circuit",
      description: "Build a simple LED circuit with power and switch",
      icon: <Zap className="w-8 h-8" />,
      color: "bg-yellow-500",
      topics: [
        "Adding a battery pack",
        "Connecting an LED",
        "Adding a push button",
        "Testing your circuit"
      ]
    },
    {
      id: 4,
      title: "Use AI Assistant",
      description: "Get help from the AI chatbot for your projects",
      icon: <Play className="w-8 h-8" />,
      color: "bg-purple-500",
      topics: [
        "Asking questions about components",
        "Requesting custom parts",
        "Getting project suggestions",
        "Learning STEM concepts"
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Builder
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <GraduationCap className="w-6 h-6 text-green-600" />
              <h1 className="text-xl font-bold">Beginner Tutorial</h1>
            </div>
          </div>
          <Badge variant="secondary" className="text-sm">
            Visual Level
          </Badge>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Intro */}
          <Card className="mb-8 border-2 border-green-500">
            <CardHeader>
              <CardTitle className="text-2xl">🎮 Welcome, Builder!</CardTitle>
              <CardDescription className="text-base">
                This tutorial will guide you through the basics of STEM Builder.
                You'll learn how to use components, build your first circuit, and
                get help from the AI assistant.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">No prior electronics knowledge required</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Components work visually - no coding needed yet</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">AI assistant ready to help 24/7</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Learn by doing and experimenting</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Steps */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Play className="w-8 h-8 text-green-600" />
            Getting Started Steps
          </h2>

          <div className="space-y-6">
            {steps.map((step, index) => (
              <Card key={step.id} className="border-l-4 border-l-green-500">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className={`${step.color} text-white rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0 font-bold text-xl`}>
                      {step.id}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {step.icon}
                        <span>{step.title}</span>
                      </CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {step.topics.map((topic, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Project Ideas */}
          <Card className="mt-8 border-2 border-blue-500 bg-blue-50/50 dark:bg-blue-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-6 h-6 text-blue-600" />
                Beginner Project Ideas
              </CardTitle>
              <CardDescription>
                Try building these simple projects to practice what you've learned!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">💡</span>
                    <span>Simple LED Circuit</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Battery + LED + Button. Learn basic power flow.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🚗</span>
                    <span>Traffic Light System</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Multiple LEDs + timer. Create sequential patterns.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🎯</span>
                    <span>Motion Detector</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Motion sensor + LED. Build simple automation.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🌡️</span>
                    <span>Temperature Display</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Temperature sensor + display. Monitor environment.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <Card className="mt-8 border-2 border-purple-500">
            <CardHeader>
              <CardTitle>🎓 Ready for More?</CardTitle>
              <CardDescription>
                Once you're comfortable with the basics, try intermediate tutorials!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Link href="/intermediate">
                  <Button className="flex-1">
                    Intermediate Tutorials
                  </Button>
                </Link>
                <Link href="/examples">
                  <Button variant="outline" className="flex-1">
                    View Examples Gallery
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
