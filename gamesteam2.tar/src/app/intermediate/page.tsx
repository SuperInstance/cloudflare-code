'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Terminal, CheckCircle, Share2, Zap, Cpu } from 'lucide-react'
import Link from 'next/link'

export default function IntermediateTutorial() {
  const steps = [
    {
      id: 1,
      title: "Understanding Wiring Connections",
      description: "Learn how components connect electrically and trace circuits",
      icon: <Share2 className="w-8 h-8" />,
      color: "bg-blue-500",
      topics: [
        "Switch to Wiring detail level",
        "Understanding pin connections",
        "Power flow and ground connections",
        "Series vs parallel circuits"
      ]
    },
    {
      id: 2,
      title: "Working with Sensors",
      description: "Integrate sensors into your projects for intelligent behavior",
      icon: <Zap className="w-8 h-8" />,
      color: "bg-purple-500",
      topics: [
        "Digital vs analog sensors",
        "Sensor data reading",
        "Threshold detection",
        "Sensor outputs and triggers"
      ]
    },
    {
      id: 3,
      title: "Controlling Actuators",
      description: "Make things move with motors, servos, and other actuators",
      icon: <Terminal className="w-8 h-8" />,
      color: "bg-green-500",
      topics: [
        "Motor speed control with PWM",
        "Servo positioning",
        "Directional control",
        "Power considerations"
      ]
    },
    {
      id: 4,
      title: "Building Complete Systems",
      description: "Combine multiple components to create functional systems",
      icon: <Cpu className="w-8 h-8" />,
      color: "bg-orange-500",
      topics: [
        "Planning your circuit",
        "Component selection and placement",
        "Testing and debugging",
        "Optimization and refinement"
      ]
    }
  ]

  const circuitConcepts = [
    {
      title: "Voltage Division",
      description: "Understanding how voltage divides across series resistors",
      diagram: "Vin ── R1 ── R2 ── Vout"
    },
    {
      title: "Current Flow",
      description: "Current flows from positive to negative through complete paths",
      diagram: "+ ── Component ── -"
    },
    {
      title: "GPIO Basics",
      description: "General Purpose Input/Output pins for controlling hardware",
      diagram: "MCU ── GPIO ── Component"
    },
    {
      title: "Pull-up/Pull-down",
      description: "Ensuring stable digital inputs with resistors",
      diagram: "VCC ── Rpu ── GPIO ── Switch ── GND"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Builder
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Terminal className="w-6 h-6 text-blue-600" />
              <h1 className="text-xl font-bold">Intermediate Tutorial</h1>
            </div>
          </div>
          <Badge variant="secondary" className="text-sm">
            Wiring Level
          </Badge>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Intro */}
          <Card className="mb-8 border-2 border-blue-500">
            <CardHeader>
              <CardTitle className="text-2xl">🔌 Wiring & Circuits</CardTitle>
              <CardDescription className="text-base">
                Ready to dive deeper? This tutorial covers electrical connections,
                circuit principles, and building complete systems with sensors and actuators.
                Switch to the Wiring detail level to see real connections!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Basic component understanding required</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">See actual wiring connections</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Learn circuit principles</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Build functional systems</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Circuit Concepts */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Zap className="w-8 h-8 text-blue-600" />
            Essential Circuit Concepts
          </h2>

          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {circuitConcepts.map((concept, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="text-lg">{concept.title}</CardTitle>
                  <CardDescription>{concept.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <code className="block bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded text-sm font-mono">
                    {concept.diagram}
                  </code>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Steps */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Terminal className="w-8 h-8 text-blue-600" />
            Intermediate Building Steps
          </h2>

          <div className="space-y-6">
            {steps.map((step, index) => (
              <Card key={step.id} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className={`${step.color} text-white rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0 font-bold text-xl`}>
                      {step.id}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {step.icon}
                        <span>{step.title}</span>
                      </CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {step.topics.map((topic, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Intermediate Project Ideas */}
          <Card className="mt-8 border-2 border-purple-500 bg-purple-50/50 dark:bg-purple-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="w-6 h-6 text-purple-600" />
                Intermediate Project Ideas
              </CardTitle>
              <CardDescription>
                Challenge yourself with these more complex projects!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🤖</span>
                    <span>Smart Robot Base</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Motor + sensors + MCU. Autonomous movement.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🌡️</span>
                    <span>Climate Station</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Multiple sensors + display. Monitor environment.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🚗</span>
                    <span>Automated Irrigation</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Moisture sensor + pump. Smart watering.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🔒</span>
                    <span>Security System</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Motion + camera + alarm. Protect your space.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <Card className="mt-8 border-2 border-orange-500">
            <CardHeader>
              <CardTitle>💻 Ready for Code?</CardTitle>
              <CardDescription>
                Mastered wiring? Dive into programming with advanced tutorials!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Link href="/advanced">
                  <Button className="flex-1">
                    Advanced Tutorials
                  </Button>
                </Link>
                <Link href="/examples">
                  <Button variant="outline" className="flex-1">
                    View Examples Gallery
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
