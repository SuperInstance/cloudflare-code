'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, BookOpen, GraduationCap, Terminal, Code2, Zap, Eye, Share2 } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

const exampleProjects = [
  {
    id: 'simple-led',
    title: 'Simple LED Circuit',
    level: 'beginner',
    category: 'Lighting',
    description: 'Learn basic circuit with battery, LED, and button',
    components: ['Battery Pack', 'LED', 'Push Button'],
    difficulty: 1,
    timeEstimate: '10 min',
    icon: <Zap className="w-8 h-8" />
  },
  {
    id: 'traffic-light',
    title: 'Traffic Light System',
    level: 'beginner',
    category: 'Lighting',
    description: 'Create sequential LED patterns with a timer circuit',
    components: ['Battery Pack', 'LED (3)', 'Temperature Sensor'],
    difficulty: 2,
    timeEstimate: '20 min',
    icon: <Eye className="w-8 h-8" />
  },
  {
    id: 'motion-detector',
    title: 'Motion Detector',
    level: 'beginner',
    category: 'Sensors',
    description: 'PIR sensor triggers LED when motion is detected',
    components: ['Battery Pack', 'Motion Sensor (PIR)', 'LED'],
    difficulty: 2,
    timeEstimate: '15 min',
    icon: <Eye className="w-8 h-8" />
  },
  {
    id: 'temperature-display',
    title: 'Temperature Display',
    level: 'intermediate',
    category: 'Sensors',
    description: 'Read temperature sensor and display value on LEDs',
    components: ['Battery Pack', 'Temperature Sensor', 'LED (4)', 'ESP32'],
    difficulty: 3,
    timeEstimate: '30 min',
    icon: <Terminal className="w-8 h-8" />
  },
  {
    id: 'smart-robot',
    title: 'Smart Robot Base',
    level: 'intermediate',
    category: 'Robotics',
    description: 'Autonomous robot with obstacle avoidance and navigation',
    components: ['Battery Pack', 'ESP32', 'DC Motor (2)', 'Wheel (2)', 'Ultrasonic Sensor (2)', 'LED (2)'],
    difficulty: 4,
    timeEstimate: '45 min',
    icon: <Zap className="w-8 h-8" />
  },
  {
    id: 'climate-station',
    title: 'Climate Station',
    level: 'intermediate',
    category: 'Sensors',
    description: 'Monitor temperature, humidity, and display data',
    components: ['Battery Pack', 'Jetson Nano', 'Temperature Sensor', 'LED (2)', 'WiFi Module'],
    difficulty: 4,
    timeEstimate: '40 min',
    icon: <Terminal className="w-8 h-8" />
  },
  {
    id: 'servo-arm',
    title: 'Servo Arm',
    level: 'intermediate',
    category: 'Robotics',
    description: 'Multi-joint robotic arm with precise positioning',
    components: ['Battery Pack', 'ESP32', 'Servo Motor (3)', 'Push Button (3)'],
    difficulty: 3,
    timeEstimate: '35 min',
    icon: <Share2 className="w-8 h-8" />
  },
  {
    id: 'pid-motor',
    title: 'PID Motor Control',
    level: 'advanced',
    category: 'Control Systems',
    description: 'Precise speed control with PID algorithm implementation',
    components: ['Battery Pack', 'ESP32', 'DC Motor', 'Encoder', 'LED'],
    difficulty: 5,
    timeEstimate: '60 min',
    icon: <Code2 className="w-8 h-8" />
  },
  {
    id: 'i2c-sensor',
    title: 'I2C Sensor Network',
    level: 'advanced',
    category: 'Communication',
    description: 'Multiple sensors on I2C bus with data logging',
    components: ['Battery Pack', 'ESP32', 'Temperature Sensor (2)', 'Push Button', 'LED'],
    difficulty: 5,
    timeEstimate: '50 min',
    icon: <Code2 className="w-8 h-8" />
  },
  {
    id: 'autonomous-drone',
    title: 'Autonomous Drone',
    level: 'advanced',
    category: 'Robotics',
    description: 'Flight controller with IMU, GPS, and motor control',
    components: ['Battery Pack', 'Jetson Nano', 'DC Motor (4)', 'WiFi Module', 'Ultrasonic Sensor', 'LED (2)'],
    difficulty: 5,
    timeEstimate: '90 min',
    icon: <Zap className="w-8 h-8" />
  },
  {
    id: 'smart-home',
    title: 'Smart Home Hub',
    level: 'advanced',
    category: 'IoT',
    description: 'Complete home automation with sensors, actuators, and cloud integration',
    components: ['Battery Pack', 'Jetson Nano', 'WiFi Module', 'LED (8)', 'Push Button (4)', 'Temperature Sensor', 'Motion Sensor'],
    difficulty: 5,
    timeEstimate: '75 min',
    icon: <Code2 className="w-8 h-8" />
  },
  {
    id: 'line-follower',
    title: 'Line Following Robot',
    level: 'intermediate',
    category: 'Robotics',
    description: 'Robot that follows a line using IR sensors',
    components: ['Battery Pack', 'ESP32', 'DC Motor (2)', 'Wheel (2)', 'Temperature Sensor (2)', 'LED (2)'],
    difficulty: 3,
    timeEstimate: '40 min',
    icon: <Terminal className="w-8 h-8" />
  },
  {
    id: 'data-logger',
    title: 'Data Logger System',
    level: 'advanced',
    category: 'Data',
    description: 'High-frequency sensor data logging with R2 storage',
    components: ['Battery Pack', 'Jetson Nano', 'Temperature Sensor', 'WiFi Module', 'Push Button'],
    difficulty: 4,
    timeEstimate: '45 min',
    icon: <Code2 className="w-8 h-8" />
  }
]

const levelConfig = {
  beginner: {
    label: 'Beginner',
    icon: <GraduationCap className="w-5 h-5" />,
    color: 'bg-green-500',
    textColor: 'text-green-600'
  },
  intermediate: {
    label: 'Intermediate',
    icon: <Terminal className="w-5 h-5" />,
    color: 'bg-blue-500',
    textColor: 'text-blue-600'
  },
  advanced: {
    label: 'Advanced',
    icon: <Code2 className="w-5 h-5" />,
    color: 'bg-purple-500',
    textColor: 'text-purple-600'
  }
}

export default function ExamplesPage() {
  const [filter, setFilter] = useState<'all' | 'beginner' | 'intermediate' | 'advanced'>('all')

  const filteredProjects = filter === 'all'
    ? exampleProjects
    : exampleProjects.filter(p => p.level === filter)

  const projectsByLevel = {
    beginner: exampleProjects.filter(p => p.level === 'beginner'),
    intermediate: exampleProjects.filter(p => p.level === 'intermediate'),
    advanced: exampleProjects.filter(p => p.level === 'advanced')
  }

  const DifficultyStars = ({ level }: { level: number }) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <div
            key={star}
            className={`w-3 h-3 rounded-sm ${
              star <= level
                ? 'bg-yellow-400'
                : 'bg-gray-300 dark:bg-gray-700'
            }`}
          />
        ))}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Builder
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-orange-500" />
              <h1 className="text-xl font-bold">Project Examples</h1>
            </div>
          </div>
          <Badge variant="secondary" className="text-sm">
            {exampleProjects.length} Projects
          </Badge>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Intro */}
          <Card className="mb-8 border-2 border-orange-500">
            <CardHeader>
              <CardTitle className="text-2xl">📚 Example Projects Gallery</CardTitle>
              <CardDescription className="text-base">
                Browse our collection of example projects organized by skill level.
                Each example includes component lists, difficulty rating, and time estimates.
                Click to open and learn from ready-made designs!
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Filter Tabs */}
          <div className="flex gap-2 mb-6">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              onClick={() => setFilter('all')}
            >
              All ({exampleProjects.length})
            </Button>
            <Button
              variant={filter === 'beginner' ? 'default' : 'outline'}
              className="gap-2"
              onClick={() => setFilter('beginner')}
            >
              <GraduationCap className="w-4 h-4 text-green-600" />
              Beginner ({projectsByLevel.beginner.length})
            </Button>
            <Button
              variant={filter === 'intermediate' ? 'default' : 'outline'}
              className="gap-2"
              onClick={() => setFilter('intermediate')}
            >
              <Terminal className="w-4 h-4 text-blue-600" />
              Intermediate ({projectsByLevel.intermediate.length})
            </Button>
            <Button
              variant={filter === 'advanced' ? 'default' : 'outline'}
              className="gap-2"
              onClick={() => setFilter('advanced')}
            >
              <Code2 className="w-4 h-4 text-purple-600" />
              Advanced ({projectsByLevel.advanced.length})
            </Button>
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => {
              const config = levelConfig[project.level as keyof typeof levelConfig]
              return (
                <Card key={project.id} className="hover:shadow-lg transition-shadow border-2 hover:border-orange-400 cursor-pointer group">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {project.icon}
                        <CardTitle className="text-lg group-hover:text-orange-600 transition-colors">
                          {project.title}
                        </CardTitle>
                      </div>
                      <Badge
                        variant="outline"
                        className={`${config.color} text-white`}
                      >
                        <span className="flex items-center gap-1">
                          {config.icon}
                          {config.label}
                        </span>
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Badge variant="secondary">{project.category}</Badge>
                      <span>⏱ {project.timeEstimate}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="mb-4">
                      {project.description}
                    </CardDescription>
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-semibold mb-2">Difficulty:</h4>
                        <DifficultyStars level={project.difficulty} />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold mb-2">Components:</h4>
                        <div className="flex flex-wrap gap-1">
                          {project.components.map((comp, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {comp}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Button className="w-full mt-2">
                        <Zap className="w-4 h-4 mr-2" />
                        Build This Project
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Quick Links */}
          <Card className="mt-8 border-2 border-orange-500 bg-orange-50/50 dark:bg-orange-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-orange-600" />
                Quick Learning Links
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <Link href="/beginner" className="no-underline">
                  <Button variant="outline" className="w-full">
                    <GraduationCap className="w-4 h-4 mr-2 text-green-600" />
                    Beginner Tutorial
                  </Button>
                </Link>
                <Link href="/intermediate" className="no-underline">
                  <Button variant="outline" className="w-full">
                    <Terminal className="w-4 h-4 mr-2 text-blue-600" />
                    Intermediate Tutorial
                  </Button>
                </Link>
                <Link href="/advanced" className="no-underline">
                  <Button variant="outline" className="w-full">
                    <Code2 className="w-4 h-4 mr-2 text-purple-600" />
                    Advanced Tutorial
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
