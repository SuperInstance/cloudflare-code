'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Code2, CheckCircle, Cpu, Database, Zap } from 'lucide-react'
import Link from 'next/link'

export default function AdvancedTutorial() {
  const steps = [
    {
      id: 1,
      title: "Programming with Microcontrollers",
      description: "Write code to control ESP32, Jetson, and other MCUs",
      icon: <Code2 className="w-8 h-8" />,
      color: "bg-purple-500",
      topics: [
        "Switch to Code detail level",
        "Understanding generated code snippets",
        "Digital I/O programming",
        "Analog read operations",
        "Interrupts and timers"
      ]
    },
    {
      id: 2,
      title: "Sensor Data Processing",
      description: "Process sensor data with filtering and algorithms",
      icon: <Database className="w-8 h-8" />,
      color: "bg-pink-500",
      topics: [
        "Raw sensor data reading",
        "Noise filtering techniques",
        "Moving average smoothing",
        "Threshold detection",
        "Data logging to storage"
      ]
    },
    {
      id: 3,
      title: "Motor Control Algorithms",
      description: "Implement advanced control for precise movement",
      icon: <Zap className="w-8 h-8" />,
      color: "bg-orange-500",
      topics: [
        "PID control systems",
        "Motor speed regulation",
        "Servo angle control",
        "Encoder feedback",
        "Closed-loop control"
      ]
    },
    {
      id: 4,
      title: "Communication Protocols",
      description: "Enable components to communicate with each other",
      icon: <Cpu className="w-8 h-8" />,
      color: "bg-cyan-500",
      topics: [
        "UART serial communication",
        "I2C bus protocol",
        "SPI interface",
        "Wireless communication (WiFi/Bluetooth)",
        "Data packet structure"
      ]
    }
  ]

  const codeExamples = [
    {
      title: "Digital Output",
      language: "Arduino/C++",
      code: `// Blink LED on GPIO pin
const int ledPin = 2;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  digitalWrite(ledPin, HIGH);
  delay(1000);
  digitalWrite(ledPin, LOW);
  delay(1000);
}`
    },
    {
      title: "Analog Read",
      language: "Arduino/C++",
      code: `// Read temperature sensor
const int sensorPin = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int value = analogRead(sensorPin);
  float voltage = value * (5.0 / 1023.0);
  Serial.print("Voltage: ");
  Serial.println(voltage);
  delay(100);
}`
    },
    {
      title: "PWM Motor Control",
      language: "Python/ESP32",
      code: `# Control motor speed with PWM
import machine
import time

pwm = machine.PWM(machine.Pin(14), freq=1000)

def set_motor_speed(speed):
    # Speed from 0 to 100
    duty = int(speed * 1023 / 100)
    pwm.duty_u16(duty)

# Ramp motor up
for i in range(0, 101, 10):
    set_motor_speed(i)
    time.sleep(0.1)`
    },
    {
      title: "I2C Sensor Read",
      language: "Python",
      code: `# Read from I2C sensor
from machine import I2C

i2c = I2C(scl=machine.Pin(5), sda=machine.Pin(4))

def read_sensor(address, register):
    i2c.writeto(address, bytes([register]))
    data = i2c.readfrom(address, 2)
    return (data[0] << 8) | data[1]

temperature = read_sensor(0x48, 0x00)
print(f"Temperature: {temperature}°C")`
    }
  ]

  const advancedConcepts = [
    {
      title: "PID Control",
      description: "Proportional-Integral-Derivative controller for precise motor/actuator control"
    },
    {
      title: "Interrupts",
      description: "Respond immediately to external events without continuous polling"
    },
    {
      title: "Real-time Constraints",
      description: "Understanding timing requirements and critical sections in code"
    },
    {
      title: "State Machines",
      description: "Model system behavior with states and transitions"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Builder
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Code2 className="w-6 h-6 text-purple-600" />
              <h1 className="text-xl font-bold">Advanced Tutorial</h1>
            </div>
          </div>
          <Badge variant="secondary" className="text-sm">
            Code Level
          </Badge>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Intro */}
          <Card className="mb-8 border-2 border-purple-500">
            <CardHeader>
              <CardTitle className="text-2xl">💻 Programming & Advanced Control</CardTitle>
              <CardDescription className="text-base">
                Dive into programming microcontrollers, implementing algorithms, and
                building complex systems. Switch to the Code detail level to see
                real code snippets and customize them!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Programming experience recommended</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Modify generated code snippets</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Implement advanced algorithms</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Build fully programmable systems</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Advanced Concepts */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Database className="w-8 h-8 text-purple-600" />
            Advanced Concepts
          </h2>

          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {advancedConcepts.map((concept, index) => (
              <Card key={index} className="border-l-4 border-l-purple-500">
                <CardHeader>
                  <CardTitle className="text-lg">{concept.title}</CardTitle>
                  <CardDescription>{concept.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>

          {/* Code Examples */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Code2 className="w-8 h-8 text-purple-600" />
            Code Examples
          </h2>

          <div className="space-y-4 mb-8">
            {codeExamples.map((example, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{example.title}</CardTitle>
                    <Badge variant="outline" className="text-xs font-mono">
                      {example.language}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto text-sm">
                    <code className="text-slate-900 dark:text-slate-100">
                      {example.code}
                    </code>
                  </pre>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Steps */}
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Zap className="w-8 h-8 text-purple-600" />
            Advanced Building Steps
          </h2>

          <div className="space-y-6 mb-8">
            {steps.map((step, index) => (
              <Card key={step.id} className="border-l-4 border-l-purple-500">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className={`${step.color} text-white rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0 font-bold text-xl`}>
                      {step.id}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {step.icon}
                        <span>{step.title}</span>
                      </CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {step.topics.map((topic, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Advanced Project Ideas */}
          <Card className="border-2 border-orange-500 bg-orange-50/50 dark:bg-orange-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-6 h-6 text-orange-600" />
                Advanced Project Ideas
              </CardTitle>
              <CardDescription>
                Push your skills with these challenging projects!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🤖</span>
                    <span>Autonomous Robot</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Computer vision + navigation + AI. Full autonomy.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🏠</span>
                    <span>Smart Home Hub</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Multiple devices + automation + control. Full integration.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">📡</span>
                    <span>Drone Flight Controller</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    IMU + motor control + telemetry. Flight algorithms.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <span className="text-2xl">🎨</span>
                    <span>AI-Powered Art</span>
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Motors + sensors + ML. Generative creativity.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
